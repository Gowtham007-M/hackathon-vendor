// App.js - Main Application Component with Complete Database Integration and Real-time Features
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { RealtimeProvider, NotificationContainer, ConnectionStatus } from './contexts/RealtimeContext'; // Removed addNotification from import as it's not used directly here

// Import Components
import HomePage from './components/HomePage';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import VendorDashboard from './components/VendorDashboard';
import SupplierDashboard from './components/SupplierDashboard';
import SupplierDetailsPage from './components/SupplierDetailsPage';
import CartPage from './components/CartPage';
import OrderConfirmationPage from './components/OrderConfirmationPage';
import PastOrdersPage from './components/PastOrdersPage';
import Navigation from './components/Navigation';

// Configure axios defaults
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
axios.defaults.baseURL = API_BASE_URL;

const VendorVibeApp = () => {
  // State Management
  const [currentView, setCurrentView] = useState('home');
  const [userType, setUserType] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);

  // Check for existing token on app load
  useEffect(() => {
    const initializeApp = async () => {
      try {
        const token = localStorage.getItem('token');
        const storedUserType = localStorage.getItem('userType');
        const storedUserData = localStorage.getItem('userData');

        if (token && storedUserType && storedUserData) {
          // Set axios authorization header
          axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

          try {
            // Verify token is still valid
            const response = await axios.get('/auth/verify');

            if (response.data.success) {
              const userData = JSON.parse(storedUserData);
              setCurrentUser(userData);
              setUserType(storedUserType);
              setIsLoggedIn(true);
              setCurrentView(storedUserType === 'vendor' ? 'vendorDashboard' : 'supplierDashboard');

              // Load user's cart and orders if vendor
              if (storedUserType === 'vendor') {
                await loadUserData(token);
              }
            } else {
              clearAuthData();
            }
          } catch (error) {
            console.error('Token verification failed:', error);
            clearAuthData();
          }
        }
      } catch (error) {
        console.error('App initialization error:', error);
        clearAuthData();
      } finally {
        setIsInitializing(false);
      }
    };

    initializeApp();
  }, []);

  // Load user's cart and orders
  const loadUserData = async (token) => {
    try {
      const headers = { Authorization: `Bearer ${token}` };

      // Load cart
      const cartResponse = await axios.get('/cart', { headers });
      // Assuming cartResponse.data is the cart object directly, or has a 'cart' property
      if (cartResponse.data) { // Check if data exists
        setCart(cartResponse.data.items || []); // Assuming cart data has an 'items' array
      }


      // Load orders
      const ordersResponse = await axios.get('/orders', { headers });
      if (ordersResponse.data) { // Check if data exists
        setOrders(ordersResponse.data || []); // Assuming orders data is an array directly
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  // Clear authentication data
  const clearAuthData = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userType');
    localStorage.removeItem('userData');
    delete axios.defaults.headers.common['Authorization'];
    setCurrentUser(null);
    setUserType(null);
    setIsLoggedIn(false);
    setCurrentView('home');
    setCart([]);
    setOrders([]);
  };

  // Authentication Functions
  const handleRegister = async (formData) => {
    setIsLoading(true);
    try {
      console.log('App.js - Sending registration data:', formData);

      const response = await axios.post('/auth/register', formData, {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 10000
      });

      console.log('App.js - Registration response:', response.data);

      if (response.status === 201 || response.data.success) {
        return {
          success: true,
          message: response.data.message || 'Registration successful! Please login.'
        };
      } else {
        return {
          success: false,
          message: response.data.error || response.data.message || 'Registration failed.'
        };
      }
    } catch (error) {
      console.error('App.js - Registration error:', error);

      if (error.response) {
        const errorMessage = error.response.data?.error ||
                             error.response.data?.message ||
                             `Registration failed (Error ${error.response.status})`;
        return {
          success: false,
          message: errorMessage
        };
      } else if (error.request) {
        return {
          success: false,
          message: 'Network error. Please check your connection and try again.'
        };
      } else {
        return {
          success: false,
          message: 'An unexpected error occurred. Please try again.'
        };
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (username, password, type) => {
    // Prevent multiple simultaneous login attempts
    if (isLoading) {
      console.log('Login already in progress, ignoring duplicate request');
      return { success: false, message: 'Login in progress...' };
    }

    setIsLoading(true);

    try {
      console.log('App.js - Attempting login:', { username, type }); // Log 'type' directly

      // Clear any existing auth data before login
      clearAuthData();

      const response = await axios.post('/auth/login', {
        username: username.trim(),
        password,
        type: type, // Corrected from 'userType' to 'type'
      }, {
        timeout: 10000,
        headers: {
          'Content-Type': 'application/json'
        }
      });

      console.log('App.js - Login response:', response.data);

      if (response.data.message === 'Login successful' && response.data.token) { // Check for specific message and token
        const { token, user } = response.data;

        // Store authentication data
        localStorage.setItem('token', token);
        localStorage.setItem('userType', type); // Store the correct type
        localStorage.setItem('userData', JSON.stringify(user));

        // Set axios authorization header
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

        // Update state
        setCurrentUser(user);
        setUserType(type);
        setIsLoggedIn(true);
        setCurrentView(type === 'vendor' ? 'vendorDashboard' : 'supplierDashboard');

        // Load user data if vendor
        if (type === 'vendor') {
          await loadUserData(token);
        }

        return { success: true, message: 'Login successful!', token, user };
      } else {
        return {
          success: false,
          message: response.data.message || response.data.error || 'Login failed'
        };
      }
    } catch (error) {
      console.error('App.js - Login error:', error);

      // Clear any stored token on error
      clearAuthData();

      if (error.response) {
        const status = error.response.status;
        const errorData = error.response.data;

        let errorMessage;
        if (status === 401) {
          errorMessage = 'Invalid username or password';
        } else if (status === 400) {
          errorMessage = errorData?.error || errorData?.message || 'Invalid request';
        } else if (status === 500) {
          errorMessage = 'Server error. Please try again later.';
        } else {
          errorMessage = errorData?.error || errorData?.message || `Login failed (Error ${status})`;
        }

        return { success: false, message: errorMessage };
      } else if (error.request) {
        return {
          success: false,
          message: 'Network error. Please check your connection and try again.'
        };
      } else {
        return {
          success: false,
          message: 'An unexpected error occurred. Please try again.'
        };
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    console.log('User logging out');
    clearAuthData();
    setIsLoading(false);
  };

  // Database-integrated Cart Functions
  const addToCart = async (product, quantity = 1) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No auth token found');
        return;
      }

      // Sync with server
      const response = await axios.post('/cart', { // Changed to /cart as per routes
        productId: product._id,
        quantity
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // Update local state based on server response
      if (response.data && response.data.items) {
        setCart(response.data.items);
      } else {
        console.warn('Server response for add to cart did not contain items array:', response.data);
      }

    } catch (error) {
      console.error('Error adding to cart:', error);
      // Revert local state if server request fails (optional, depends on desired UX)
      // You might want to fetch the cart again from the server to ensure consistency
    }
  };

  const removeFromCart = async (productId) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      const response = await axios.delete(`/cart/${productId}`, { // Changed to /cart/:productId
        headers: { Authorization: `Bearer ${token}` }
      });

      // Update local state based on server response
      if (response.data && response.data.cart && response.data.cart.items) {
        setCart(response.data.cart.items);
      } else {
        console.warn('Server response for remove from cart did not contain expected cart items:', response.data);
      }

    } catch (error) {
      console.error('Error removing from cart:', error);
      // Could implement rollback logic here
    }
  };

  const updateCartQuantity = async (productId, newQuantity) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      if (newQuantity <= 0) {
        return removeFromCart(productId);
      }

      const response = await axios.put(`/cart/${productId}`, { // Changed to /cart/:productId
        quantity: newQuantity
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // Update local state based on server response
      if (response.data && response.data.cart && response.data.cart.items) {
        setCart(response.data.cart.items);
      } else {
        console.warn('Server response for update cart quantity did not contain expected cart items:', response.data);
      }

    } catch (error) {
      console.error('Error updating cart quantity:', error);
    }
  };

  // Database-integrated Order Functions
  const placeOrder = async (orderData) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        return { success: false, message: 'Authentication required' };
      }

      const response = await axios.post('/orders', {
        items: cart.map(item => ({
          product: item.product._id, // Ensure product ID is sent, not whole object
          name: item.name,
          quantity: item.quantity,
          price: item.price
        })),
        ...orderData
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      const newOrder = response.data; // Assuming the order object is directly in response.data
      setOrders([newOrder, ...orders]);
      setCart([]); // Clear cart after successful order
      setCurrentView('orderConfirmation');

      return { success: true, order: newOrder };
    } catch (error) {
      console.error('Error placing order:', error);
      return {
        success: false,
        message: error.response?.data?.error || error.response?.data?.message || 'Failed to place order'
      };
    }
  };

  const handleSupplierSelect = async (supplier) => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      // Fetch detailed supplier information
      const response = await axios.get(`/suppliers/${supplier._id || supplier.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setCurrentUser({...currentUser, selectedSupplier: response.data}); // Assuming response.data is the supplier object
      setCurrentView('supplierDetails');
    } catch (error) {
      console.error('Error fetching supplier details:', error);
      // Fallback to using the supplier data we already have
      setCurrentUser({...currentUser, selectedSupplier: supplier});
      setCurrentView('supplierDetails');
    }
  };

  // Show loading screen during initialization
  if (isInitializing) {
    return (
      <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light">
        <div className="text-center">
          <div className="spinner-border text-primary mb-3" role="status" style={{width: '3rem', height: '3rem'}}>
            <span className="visually-hidden">Loading...</span>
          </div>
          <h4 className="text-primary mb-2">VendorVibe</h4>
          <p className="text-muted">Initializing application...</p>
          <div className="progress" style={{width: '200px', height: '4px'}}>
            <div className="progress-bar progress-bar-striped progress-bar-animated"
                 style={{width: '100%'}}></div>
          </div>
        </div>
      </div>
    );
  }

  // View Rendering Logic
  const renderCurrentView = () => {
    switch (currentView) {
      case 'home':
        return <HomePage onViewChange={setCurrentView} />;

      case 'vendorLogin':
        return (
          <LoginPage
            type="vendor"
            onLogin={handleLogin}
            onViewChange={setCurrentView}
            isLoading={isLoading}
          />
        );

      case 'supplierLogin':
        return (
          <LoginPage
            type="supplier"
            onLogin={handleLogin}
            onViewChange={setCurrentView}
            isLoading={isLoading}
          />
        );

      case 'vendorRegister':
        return (
          <RegisterPage
            type="vendor"
            onRegister={handleRegister}
            onViewChange={setCurrentView}
            isLoading={isLoading}
          />
        );

      case 'supplierRegister':
        return (
          <RegisterPage
            type="supplier"
            onRegister={handleRegister}
            onViewChange={setCurrentView}
            isLoading={isLoading}
          />
        );

      case 'vendorDashboard':
        return (
          <VendorDashboard
            currentUser={currentUser}
            cart={cart}
            orders={orders}
            onViewChange={setCurrentView}
            onSupplierSelect={handleSupplierSelect}
            onLogout={handleLogout}
          />
        );

      case 'supplierDashboard':
        return (
          <SupplierDashboard
            currentUser={currentUser}
            onViewChange={setCurrentView}
            onLogout={handleLogout}
          />
        );

      case 'supplierDetails':
        return (
          <SupplierDetailsPage
            supplier={currentUser?.selectedSupplier}
            onAddToCart={addToCart}
            onViewChange={setCurrentView}
            currentUser={currentUser}
          />
        );

      case 'cart':
        return (
          <CartPage
            cart={cart}
            onRemoveFromCart={removeFromCart}
            onUpdateQuantity={updateCartQuantity}
            onPlaceOrder={placeOrder}
            onViewChange={setCurrentView}
            currentUser={currentUser}
          />
        );

      case 'orderConfirmation':
        return (
          <OrderConfirmationPage
            orders={orders}
            onViewChange={setCurrentView}
            currentUser={currentUser}
          />
        );

      case 'pastOrders':
        return (
          <PastOrdersPage
            orders={orders}
            onViewChange={setCurrentView}
            currentUser={currentUser}
          />
        );

      default:
        return <HomePage onViewChange={setCurrentView} />;
    }
  };

  return (
    <RealtimeProvider>
      <div className="App">
        {/* Bootstrap CSS */}
        <link
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css"
          rel="stylesheet"
        />
        {/* Font Awesome for icons */}
        <link
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
          rel="stylesheet"
        />

        {/* Global Loading Overlay */}
        {isLoading && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 9999
          }}>
            <div className="text-white text-center">
              <div className="spinner-border mb-3" role="status" style={{width: '3rem', height: '3rem'}}>
                <span className="visually-hidden">Loading...</span>
              </div>
              <h5 className="mb-2">VendorVibe</h5>
              <p className="mb-0">Please wait...</p>
            </div>
          </div>
        )}

        {/* Real-time Components */}
        <NotificationContainer />
        {isLoggedIn && <ConnectionStatus />}

        {/* Navigation - only show when logged in */}
        {isLoggedIn && (
          <Navigation
            currentUser={currentUser}
            userType={userType}
            onLogout={handleLogout}
            onViewChange={setCurrentView}
            cartCount={cart.length}
            currentView={currentView}
          />
        )}

        {/* Main Content */}
        <main className={isLoggedIn ? 'pt-4' : ''}>
          {renderCurrentView()}
        </main>

        {/* Custom Styles */}
        <style>{`
          .bg-gradient-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          }
          .cursor-pointer {
            cursor: pointer;
          }
          .card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
          }
          .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
          }
          .btn {
            transition: all 0.2s ease;
          }
          .btn:hover {
            transform: translateY(-1px);
          }
          .progress-bar-animated {
            animation: progress-bar-stripes 1s linear infinite;
          }
          @keyframes progress-bar-stripes {
            0% { background-position: 1rem 0; }
            100% { background-position: 0 0; }
          }
          .notification-container {
            pointer-events: none;
          }
          .notification-container .alert {
            pointer-events: auto;
          }
          main {
            min-height: calc(100vh - 70px);
          }
          .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
        `}</style>

        {/* Bootstrap JS */}
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
      </div>
    </RealtimeProvider>
  );
};

export default VendorVibeApp;
