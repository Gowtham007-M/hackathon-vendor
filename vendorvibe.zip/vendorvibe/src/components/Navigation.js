// components/Navigation.js
import React from 'react';

const Navigation = ({ currentUser, userType, onLogout, onViewChange, cartCount }) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow">
      <div className="container">
        <button 
          className="navbar-brand fw-bold fs-3 btn btn-link text-white text-decoration-none" 
          onClick={() => onViewChange(userType === 'vendor' ? 'vendorDashboard' : 'supplierDashboard')}
          style={{ border: 'none' }}
        >
          <i className="fas fa-handshake me-2"></i>VendorVibe
        </button>
        
        <div className="navbar-nav ms-auto d-flex flex-row align-items-center">
          <span className="text-white me-3">
            <i className="fas fa-user-circle me-1"></i>
            Welcome, {currentUser?.name}
          </span>
          
          {userType === 'vendor' && (
            <button 
              className="btn btn-outline-light btn-sm me-2"
              onClick={() => onViewChange('cart')}
            >
              <i className="fas fa-shopping-cart me-1"></i>
              Cart ({cartCount})
            </button>
          )}
          
          <div className="dropdown">
            <button 
              className="btn btn-outline-light btn-sm dropdown-toggle me-2" 
              type="button" 
              data-bs-toggle="dropdown"
            >
              <i className="fas fa-user me-1"></i>Profile
            </button>
            <ul className="dropdown-menu">
              <li><button className="dropdown-item" href="#">View Profile</button></li>
              <li><button className="dropdown-item" href="#">Settings</button></li>
              <li><hr className="dropdown-divider" /></li>
              <li><button className="dropdown-item text-danger" onClick={onLogout}>Logout</button></li>
            </ul>
          </div>
          
          <button 
            className="btn btn-danger btn-sm" 
            onClick={onLogout}
          >
            <i className="fas fa-sign-out-alt me-1"></i>Logout
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;