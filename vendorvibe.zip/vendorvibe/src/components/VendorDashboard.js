// components/VendorDashboard.js - Enhanced with Real-time Features
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useRealtime, useRealtimeProducts, useRealtimeOrders, useRealtimeSuppliers } from '../contexts/RealtimeContext';

const VendorDashboard = ({ currentUser, onViewChange, onSupplierSelect }) => {
  const { isConnected, addNotification, connectSocket } = useRealtime();
  const { products } = useRealtimeProducts();
  const { orders } = useRealtimeOrders();
  const { suppliers, onlineSuppliers } = useRealtimeSuppliers();
  
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('suppliers');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [cart, setCart] = useState([]);

  const categories = ['All', 'Grains', 'Pulses', 'Spices', 'Oil', 'Sugar', 'Rice', 'Wheat', 'Other'];

  useEffect(() => {
    // Connect to WebSocket when component mounts
    const token = localStorage.getItem('token');
    if (token) {
      connectSocket(token);
    }
    
    fetchDashboardData();
  }, []);

  // Real-time connection status indicator
  const ConnectionStatus = () => (
    <div className={`badge ${isConnected ? 'bg-success' : 'bg-danger'} position-fixed`} 
         style={{top: '80px', right: '20px', zIndex: 1050}}>
      <i className={`fas fa-${isConnected ? 'wifi' : 'exclamation-triangle'} me-1`}></i>
      {isConnected ? 'Connected' : 'Disconnected'}
    </div>
  );

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      // Fetch suppliers and stats
      const [suppliersRes, statsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/suppliers', { headers }),
        axios.get('http://localhost:5000/api/dashboard/stats', { headers })
      ]);

      // Don't fetch orders here as they come from real-time hook
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      addNotification('Failed to load dashboard data', 'error');
    } finally {
      setLoading(false);
    }
  };

  const addToCart = (product, quantity = 1) => {
    const existingItem = cart.find(item => item.id === product.id);
    const updatedCart = existingItem
      ? cart.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      : [...cart, { ...product, quantity }];
    
    setCart(updatedCart);
    addNotification(`${product.name} added to cart!`, 'success', 3000);
  };

  const removeFromCart = (productId) => {
    const updatedCart = cart.filter(item => item.id !== productId);
    setCart(updatedCart);
    addNotification('Item removed from cart', 'info', 2000);
  };

  const placeOrder = async () => {
    if (cart.length === 0) {
      addNotification('Your cart is empty!', 'warning');
      return;
    }

    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const orderData = {
        items: cart.map(item => ({
          productId: item.id,
          quantity: item.quantity
        })),
        deliveryOption: 'standard',
        deliveryAddress: {
          street: '123 Main St',
          city: 'Sample City',
          state: 'Sample State',
          pincode: '123456',
          country: 'India'
        }
      };

      await axios.post('http://localhost:5000/api/orders', orderData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setCart([]);
      addNotification('Order placed successfully!', 'success', 5000);
      
      // Refresh stats after order
      const statsRes = await axios.get('http://localhost:5000/api/dashboard/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStats(statsRes.data);
      
    } catch (error) {
      console.error('Error placing order:', error);
      addNotification('Failed to place order. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const filteredSuppliers = suppliers.filter(supplier => {
    const matchesSearch = supplier.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         supplier.location?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === '' || selectedCategory === 'All' ||
                           supplier.products?.some(product => 
                             product.category === selectedCategory
                           );
    
    return matchesSearch && matchesCategory;
  });

  const getStatusColor = (status) => {
    const colors = {
      pending: 'warning',
      confirmed: 'info',
      processing: 'primary',
      shipped: 'secondary',
      delivered: 'success',
      cancelled: 'danger'
    };
    return colors[status] || 'secondary';
  };

  if (loading && suppliers.length === 0) {
    return (
      <div className="min-vh-100 d-flex align-items-center justify-content-center">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4">
      <ConnectionStatus />
      
      {/* Header */}
      <div className="row mb-4">
        <div className="col-md-8">
          <h2 className="fw-bold text-primary mb-1">
            <i className="fas fa-store me-2"></i>Vendor Dashboard
            {isConnected && (
              <span className="badge bg-success ms-2 fs-6">
                <i className="fas fa-bolt me-1"></i>Live
              </span>
            )}
          </h2>
          <p className="text-muted">Welcome back, {currentUser.name}!</p>
        </div>
        <div className="col-md-4 text-end">
          {cart.length > 0 && (
            <button 
              className="btn btn-success me-2 position-relative"
              onClick={() => onViewChange('cart')}
            >
              <i className="fas fa-shopping-cart me-2"></i>
              Cart 
              <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                {cart.length}
              </span>
            </button>
          )}
          <button 
            className="btn btn-primary"
            onClick={placeOrder}
            disabled={cart.length === 0 || loading}
          >
            {loading ? (
              <><i className="fas fa-spinner fa-spin me-2"></i>Processing...</>
            ) : (
              <><i className="fas fa-check me-2"></i>Place Order</>
            )}
          </button>
        </div>
      </div>

      {/* Enhanced Stats Cards with Real-time Data */}
      <div className="row mb-4">
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-primary text-white">
            <div className="card-body">
              <i className="fas fa-truck fa-2x mb-2"></i>
              <h3 className="fw-bold">{suppliers.length || 0}</h3>
              <p className="mb-1">Total Suppliers</p>
              <small className="opacity-75">
                <i className="fas fa-circle text-success me-1"></i>
                {onlineSuppliers ? onlineSuppliers.size : 0} online
              </small>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-success text-white">
            <div className="card-body">
              <i className="fas fa-shopping-cart fa-2x mb-2"></i>
              <h3 className="fw-bold">{orders.length || 0}</h3>
              <p className="mb-1">Total Orders</p>
              <small className="opacity-75">Real-time tracking</small>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-warning text-white">
            <div className="card-body">
              <i className="fas fa-clock fa-2x mb-2"></i>
              <h3 className="fw-bold">
                {orders.filter(order => ['pending', 'confirmed', 'processing'].includes(order.status)).length || 0}
              </h3>
              <p className="mb-1">Pending Orders</p>
              <small className="opacity-75">Live updates</small>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-info text-white">
            <div className="card-body">
              <i className="fas fa-rupee-sign fa-2x mb-2"></i>
              <h3 className="fw-bold">
                ₹{orders.reduce((sum, order) => sum + (order.total || 0), 0).toFixed(2)}
              </h3>
              <p className="mb-1">Total Spent</p>
              <small className="opacity-75">Live calculation</small>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="row mb-4">
        <div className="col">
          <ul className="nav nav-pills">
            <li className="nav-item">
              <button 
                className={`nav-link ${activeTab === 'suppliers' ? 'active' : ''}`}
                onClick={() => setActiveTab('suppliers')}
              >
                <i className="fas fa-truck me-2"></i>Browse Suppliers
                <span className="badge bg-light text-dark ms-1">{suppliers.length}</span>
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => setActiveTab('orders')}
              >
                <i className="fas fa-list-alt me-2"></i>My Orders
                <span className="badge bg-light text-dark ms-1">{orders.length}</span>
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link ${activeTab === 'cart' ? 'active' : ''}`}
                onClick={() => setActiveTab('cart')}
              >
                <i className="fas fa-shopping-cart me-2"></i> Cart
                <span className="badge bg-danger text-white ms-1">{cart.length}</span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Suppliers Tab with Real-time Online Status */}
      {activeTab === 'suppliers' && (
        <div>
          {/* Search and Filter */}
          <div className="row mb-4">
            <div className="col-md-6">
              <div className="input-group">
                <span className="input-group-text">
                  <i className="fas fa-search"></i>
                </span>
                <input type="text" className="form-control" placeholder="Search suppliers or locations..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
              </div>
            </div>
            <div className="col-md-3">
              <select className="form-select" value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} >
                <option value="">All Categories</option>
                {categories.slice(1).map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3">
              <button className="btn btn-outline-secondary w-100" onClick={() => { setSearchTerm(''); setSelectedCategory(''); }} >
                <i className="fas fa-times me-2"></i>Clear Filters
              </button>
            </div>
          </div>

          {/* Real-time Suppliers Grid */}
          <div className="row">
            {filteredSuppliers.map(supplier => {
              const isOnline = onlineSuppliers.has(supplier.id);
              return (
                <div key={supplier.id} className="col-lg-4 col-md-6 mb-4">
                  <div className={`card border-0 shadow-sm h-100 ${isOnline ? 'border-success' : ''}`}>
                    <div className="card-body">
                      <div className="d-flex justify-content-between align-items-start mb-3">
                        <div>
                          <h5 className="card-title fw-bold d-flex align-items-center">
                            {supplier.name}
                            <span className={`badge ms-2 ${isOnline ? 'bg-success' : 'bg-secondary'}`}>
                              <i className={`fas fa-circle me-1`}></i> {isOnline ? 'Online' : 'Offline'}
                            </span>
                          </h5>
                          {supplier.verified && (
                            <span className="badge bg-primary mb-2">
                              <i className="fas fa-check-circle me-1"></i>Verified
                            </span>
                          )}
                        </div>
                        <div className="text-end">
                          <div className="text-warning mb-1">
                            {[...Array(5)].map((_, i) => (
                              <i key={i} className={`fas fa-star ${i < Math.floor(supplier.rating || 4) ? '' : 'text-muted'}`} ></i>
                            ))}
                          </div>
                          <small className="text-muted">{supplier.rating || 4.0}</small>
                        </div>
                      </div>
                      <p className="text-muted mb-2">
                        <i className="fas fa-map-marker-alt me-2"></i> {supplier.location}
                      </p>
                      <p className="text-muted mb-3">
                        <i className="fas fa-phone me-2"></i> {supplier.contact}
                      </p>
                      <div className="mb-3">
                        <small className="text-muted">Available Products:</small>
                        <div className="mt-1">
                          {supplier.products && supplier.products.length > 0 ? (
                            <div className="d-flex flex-wrap">
                              {supplier.products.slice(0, 3).map(product => (
                                <span key={product._id} className="badge bg-light text-dark border me-1 mb-1">
                                  {product.name}
                                </span>
                              ))}
                              {supplier.products.length > 3 && (
                                <span className="badge bg-light text-dark border me-1 mb-1">
                                  +{supplier.products.length - 3} more
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-muted fst-italic">No products listed.</span>
                          )}
                        </div>
                      </div>
                      <button 
                        className="btn btn-primary btn-sm w-100"
                        onClick={() => onSupplierSelect(supplier)}
                      >
                        <i className="fas fa-eye me-2"></i>View Details
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
            {filteredSuppliers.length === 0 && !loading && (
              <div className="col-12 text-center text-muted">
                <p><i className="fas fa-info-circle me-2"></i>No suppliers found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div>
          <h4 className="fw-bold mb-3">
            <i className="fas fa-list-alt me-2"></i>My Recent Orders
            <span className="badge bg-info ms-2">{orders.length}</span>
          </h4>
          {orders.length === 0 ? (
            <div className="alert alert-info text-center" role="alert">
              <i className="fas fa-box-open me-2"></i>You haven't placed any orders yet.
            </div>
          ) : (
            <div className="accordion" id="ordersAccordion">
              {orders.slice(0, 5).map((order, index) => ( // Displaying only the first 5 orders
                <div className="accordion-item animate-row" key={order._id || index}>
                  <h2 className="accordion-header" id={`heading${order._id || index}`}>
                    <button 
                      className={`accordion-button ${index === 0 ? '' : 'collapsed'}`} 
                      type="button" 
                      data-bs-toggle="collapse" 
                      data-bs-target={`#collapse${order._id || index}`} 
                      aria-expanded={index === 0 ? 'true' : 'false'} 
                      aria-controls={`collapse${order._id || index}`}
                    >
                      <div className="d-flex justify-content-between align-items-center w-100 pe-3">
                        <div>
                          <strong>Order ID:</strong> #{order._id?.substring(0, 8) || 'N/A'} 
                          <span className={`badge bg-${getStatusColor(order.status)} ms-2`}>
                            {order.status}
                          </span>
                        </div>
                        <div>
                          <strong>Total:</strong> ₹{order.total?.toFixed(2) || '0.00'}
                          <small className="text-muted ms-3">
                            {new Date(order.orderDate).toLocaleDateString()}
                          </small>
                        </div>
                      </div>
                    </button>
                  </h2>
                  <div 
                    id={`collapse${order._id || index}`} 
                    className={`accordion-collapse collapse ${index === 0 ? 'show' : ''}`} 
                    aria-labelledby={`heading${order._id || index}`}
                    data-bs-parent="#ordersAccordion"
                  >
                    <div className="accordion-body">
                      <h6>Items:</h6>
                      <ul className="list-group list-group-flush mb-3">
                        {order.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="list-group-item d-flex justify-content-between align-items-center">
                            <span>{item.name} x {item.quantity} kg</span>
                            <span className="fw-bold">₹{(item.price * item.quantity).toFixed(2)}</span>
                          </li>
                        ))}
                      </ul>
                      <p><strong>Delivery Option:</strong> {order.deliveryOption}</p>
                      <p><strong>Delivery Address:</strong> {order.deliveryAddress?.street}, {order.deliveryAddress?.city}, {order.deliveryAddress?.state} - {order.deliveryAddress?.pincode}</p>
                      <button 
                        className="btn btn-info btn-sm"
                        onClick={() => onViewChange('pastOrders')} // Link to PastOrdersPage
                      >
                        <i className="fas fa-info-circle me-2"></i>View All Orders
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Cart Tab */}
      {activeTab === 'cart' && (
        <div>
          <h4 className="fw-bold mb-3">
            <i className="fas fa-shopping-cart me-2"></i>Your Cart
            <span className="badge bg-danger ms-2">{cart.length}</span>
          </h4>
          {cart.length === 0 ? (
            <div className="alert alert-warning text-center" role="alert">
              <i className="fas fa-shopping-basket me-2"></i>Your cart is empty. Start Browse suppliers to add items!
            </div>
          ) : (
            <div className="card shadow-sm p-3">
              <ul className="list-group list-group-flush mb-3">
                {cart.map(item => (
                  <li key={item.id} className="list-group-item d-flex justify-content-between align-items-center animate-row">
                    <div>
                      <strong>{item.name}</strong> 
                      <small className="text-muted ms-2">from {item.supplierName}</small>
                      <br/>
                      <small>Quantity: {item.quantity} kg</small>
                    </div>
                    <div className="text-end">
                      <span className="fw-bold me-3">₹{(item.price * item.quantity).toFixed(2)}</span>
                      <button 
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => removeFromCart(item.id)}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="d-flex justify-content-end align-items-center">
                <h5 className="me-3">Total: <span className="text-primary">₹{cart.reduce((sum, item) => sum + (item.price * item.quantity), 0).toFixed(2)}</span></h5>
                <button 
                  className="btn btn-success"
                  onClick={placeOrder}
                  disabled={loading}
                >
                  {loading ? (
                    <><i className="fas fa-spinner fa-spin me-2"></i>Placing Order...</>
                  ) : (
                    <><i className="fas fa-check me-2"></i>Confirm Order</>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Custom Styles */}
      <style jsx>{`
        .bg-gradient-primary {
          background: linear-gradient(135deg, #007bff, #6610f2);
        }
        
        .bg-gradient-success {
          background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .bg-gradient-warning {
          background: linear-gradient(135deg, #ffc107, #fd7e14);
        }
        
        .bg-gradient-info {
          background: linear-gradient(135deg, #17a2b8, #6f42c1);
        }
        
        .animate-row {
          animation: slideInFade 0.5s ease-in;
        }
        
        @keyframes slideInFade {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .pulse-animation {
          animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
        
        .cart-item {
          transition: all 0.3s ease;
        }
        
        .cart-item:hover {
          background-color: rgba(0,123,255,0.05);
        }
      `}</style>
    </div>
  );
};

export default VendorDashboard;