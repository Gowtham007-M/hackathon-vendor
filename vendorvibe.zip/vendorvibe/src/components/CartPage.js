// components/CartPage.js
import React, { useState } from 'react';

const CartPage = ({ cart, onRemoveFromCart, onPlaceOrder, onViewChange }) => {
  const [deliveryOption, setDeliveryOption] = useState('standard');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const bulkDiscount = cart.reduce((sum, item) => {
    const itemDiscount = item.quantity >= item.minBulk ? (item.price * item.quantity * item.discount / 100) : 0;
    return sum + itemDiscount;
  }, 0);
  
  const deliveryFee = subtotal > 50 ? 0 : (deliveryOption === 'express' ? 15 : 8);
  const couponDiscount = appliedCoupon ? (subtotal * appliedCoupon.discount / 100) : 0;
  const total = subtotal - bulkDiscount - couponDiscount + deliveryFee;

  const handleApplyCoupon = () => {
    const coupons = {
      'SAVE10': { discount: 10, description: '10% off your order' },
      'BULK15': { discount: 15, description: '15% off bulk orders' },
      'FIRST20': { discount: 20, description: '20% off first order' }
    };

    if (coupons[couponCode.toUpperCase()]) {
      setAppliedCoupon({
        code: couponCode.toUpperCase(),
        ...coupons[couponCode.toUpperCase()]
      });
      setCouponCode('');
    } else {
      alert('Invalid coupon code');
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
  };

  const updateQuantity = (itemId, newQuantity) => {
    // This would typically update the cart in the parent component
    console.log(`Update item ${itemId} to quantity ${newQuantity}`);
  };

  if (cart.length === 0) {
    return (
      <div className="container-fluid py-5 bg-light min-vh-100">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <div className="card shadow border-0">
                <div className="card-body text-center py-5">
                  <div className="mb-4">
                    <i className="fas fa-shopping-cart fs-1 text-muted mb-3"></i>
                    <h3 className="text-muted">Your cart is empty</h3>
                    <p className="text-muted">Looks like you haven't added any products to your cart yet.</p>
                  </div>
                  <button 
                    className="btn btn-primary btn-lg"
                    onClick={() => onViewChange('vendorDashboard')}
                  >
                    <i className="fas fa-store me-2"></i>Start Shopping
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4 bg-light min-vh-100">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-10">
            {/* Header */}
            <div className="card shadow border-0 mb-4">
              <div className="card-header bg-primary text-white">
                <div className="d-flex justify-content-between align-items-center">
                  <h3 className="mb-0 fw-bold">
                    <i className="fas fa-shopping-cart me-2"></i>
                    Your Shopping Cart
                  </h3>
                  <div className="d-flex align-items-center">
                    <span className="badge bg-light text-primary me-3 fs-6">
                      {cart.length} {cart.length === 1 ? 'Item' : 'Items'}
                    </span>
                    <button 
                      className="btn btn-outline-light"
                      onClick={() => onViewChange('vendorDashboard')}
                    >
                      <i className="fas fa-arrow-left me-2"></i>Continue Shopping
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="row">
              {/* Cart Items */}
              <div className="col-lg-8 mb-4">
                <div className="card shadow border-0">
                  <div className="card-header bg-white">
                    <h5 className="mb-0 fw-bold">Cart Items</h5>
                  </div>
                  <div className="card-body p-0">
                    <div className="table-responsive">
                      <table className="table table-hover mb-0">
                        <thead className="table-light">
                          <tr>
                            <th className="border-0">#</th>
                            <th className="border-0">Product</th>
                            <th className="border-0">Price/kg</th>
                            <th className="border-0">Quantity</th>
                            <th className="border-0">Bulk Discount</th>
                            <th className="border-0">Subtotal</th>
                            <th className="border-0">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {cart.map((item, index) => {
                            const itemDiscount = item.quantity >= item.minBulk ? item.discount : 0;
                            const itemSubtotal = item.price * item.quantity;
                            const discountAmount = itemSubtotal * itemDiscount / 100;
                            const itemTotal = itemSubtotal - discountAmount;

                            return (
                              <tr key={item.id} className="cart-item-row">
                                <td className="fw-bold">{index + 1}</td>
                                <td>
                                  <div className="d-flex align-items-center">
                                    <div className="product-icon bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                                      <i className="fas fa-seedling"></i>
                                    </div>
                                    <div>
                                      <h6 className="mb-0 fw-bold">{item.name}</h6>
                                      <small className="text-muted">Fresh Quality</small>
                                    </div>
                                  </div>
                                </td>
                                <td className="fw-bold text-success">${item.price}</td>
                                <td>
                                  <div className="d-flex align-items-center">
                                    <span className="fw-bold me-2">{item.quantity} kg</span>
                                    {item.quantity >= item.minBulk && (
                                      <span className="badge bg-success">
                                        <i className="fas fa-tag me-1"></i>Bulk
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td>
                                  {itemDiscount > 0 ? (
                                    <div>
                                      <span className="text-success fw-bold">{itemDiscount}%</span>
                                      <br />
                                      <small className="text-success">-${discountAmount.toFixed(2)}</small>
                                    </div>
                                  ) : (
                                    <span className="text-muted">-</span>
                                  )}
                                </td>
                                <td className="fw-bold text-primary">${itemTotal.toFixed(2)}</td>
                                <td>
                                  <button 
                                    className="btn btn-outline-danger btn-sm"
                                    onClick={() => onRemoveFromCart(item.id)}
                                    title="Remove from cart"
                                  >
                                    <i className="fas fa-trash"></i>
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Coupon Section */}
                <div className="card shadow border-0 mt-4">
                  <div className="card-header bg-white">
                    <h6 className="mb-0 fw-bold">
                      <i className="fas fa-tag me-2 text-warning"></i>
                      Apply Coupon Code
                    </h6>
                  </div>
                  <div className="card-body">
                    {!appliedCoupon ? (
                      <div className="row">
                        <div className="col-md-8">
                          <div className="input-group">
                            <input 
                              type="text" 
                              className="form-control"
                              placeholder="Enter coupon code"
                              value={couponCode}
                              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                            />
                            <button 
                              className="btn btn-outline-primary"
                              onClick={handleApplyCoupon}
                              disabled={!couponCode.trim()}
                            >
                              Apply
                            </button>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <small className="text-muted">
                            Try: SAVE10, BULK15, FIRST20
                          </small>
                        </div>
                      </div>
                    ) : (
                      <div className="alert alert-success d-flex justify-content-between align-items-center mb-0">
                        <div>
                          <i className="fas fa-check-circle me-2"></i>
                          <strong>{appliedCoupon.code}</strong> - {appliedCoupon.description}
                        </div>
                        <button 
                          className="btn btn-outline-danger btn-sm"
                          onClick={handleRemoveCoupon}
                        >
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="col-lg-4">
                <div className="card shadow border-0 sticky-top" style={{top: '100px'}}>
                  <div className="card-header bg-white">
                    <h5 className="mb-0 fw-bold">Order Summary</h5>
                  </div>
                  <div className="card-body">
                    <div className="d-flex justify-content-between mb-2">
                      <span>Subtotal ({cart.length} items):</span>
                      <span className="fw-bold">${subtotal.toFixed(2)}</span>
                    </div>
                    
                    {bulkDiscount > 0 && (
                      <div className="d-flex justify-content-between mb-2 text-success">
                        <span>Bulk Discount:</span>
                        <span className="fw-bold">-${bulkDiscount.toFixed(2)}</span>
                      </div>
                    )}
                    
                    {appliedCoupon && (
                      <div className="d-flex justify-content-between mb-2 text-success">
                        <span>Coupon ({appliedCoupon.code}):</span>
                        <span className="fw-bold">-${couponDiscount.toFixed(2)}</span>
                      </div>
                    )}

                    <div className="mb-3">
                      <label className="form-label fw-semibold">Delivery Option:</label>
                      <div className="form-check">
                        <input 
                          className="form-check-input" 
                          type="radio" 
                          name="delivery" 
                          id="standard"
                          value="standard"
                          checked={deliveryOption === 'standard'}
                          onChange={(e) => setDeliveryOption(e.target.value)}
                        />
                        <label className="form-check-label" htmlFor="standard">
                          Standard Delivery (2-3 days) - ${subtotal > 50 ? 'Free' : '$8.00'}
                        </label>
                      </div>
                      <div className="form-check">
                        <input 
                          className="form-check-input" 
                          type="radio" 
                          name="delivery" 
                          id="express"
                          value="express"
                          checked={deliveryOption === 'express'}
                          onChange={(e) => setDeliveryOption(e.target.value)}
                        />
                        <label className="form-check-label" htmlFor="express">
                          Express Delivery (1-2 days) - $15.00
                        </label>
                      </div>
                    </div>

                    <div className="d-flex justify-content-between mb-2">
                      <span>Delivery Fee:</span>
                      <span className="fw-bold">
                        {deliveryFee === 0 ? 'Free' : `${deliveryFee.toFixed(2)}`}
                      </span>
                    </div>

                    <hr />
                    
                    <div className="d-flex justify-content-between mb-4">
                      <span className="fs-5 fw-bold">Total:</span>
                      <span className="fs-4 fw-bold text-primary">${total.toFixed(2)}</span>
                    </div>

                    <button 
                      className="btn btn-success btn-lg w-100 mb-3"
                      onClick={() => onPlaceOrder({ 
                        total, 
                        deliveryOption, 
                        coupon: appliedCoupon?.code 
                      })}
                    >
                      <i className="fas fa-credit-card me-2"></i>
                      Place Order
                    </button>

                    <div className="text-center">
                      <small className="text-muted">
                        <i className="fas fa-lock me-1"></i>
                        Secure checkout powered by VendorVibe
                      </small>
                    </div>
                  </div>
                </div>

                {/* Trust Badges */}
                <div className="card shadow border-0 mt-4">
                  <div className="card-body text-center">
                    <h6 className="fw-bold mb-3">Why Shop With Us?</h6>
                    <div className="row text-center">
                      <div className="col-4">
                        <i className="fas fa-shield-alt fs-4 text-success mb-2"></i>
                        <small className="d-block">Secure Payment</small>
                      </div>
                      <div className="col-4">
                        <i className="fas fa-truck fs-4 text-primary mb-2"></i>
                        <small className="d-block">Fast Delivery</small>
                      </div>
                      <div className="col-4">
                        <i className="fas fa-undo fs-4 text-warning mb-2"></i>
                        <small className="d-block">Easy Returns</small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Styles */}
      <style jsx>{`
        .cart-item-row:hover {
          background-color: rgba(0,123,255,0.05);
        }
        
        .product-icon {
          width: 40px;
          height: 40px;
          font-size: 1.2rem;
        }
        
        .sticky-top {
          position: sticky;
          top: 100px;
          z-index: 1020;
        }
      `}</style>
    </div>
  );
};

export default CartPage;