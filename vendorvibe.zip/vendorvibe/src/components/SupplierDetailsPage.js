// components/SupplierDetailsPage.js
import React, { useState } from 'react';

const SupplierDetailsPage = ({ supplier, onAddToCart, onViewChange }) => {
  const [quantities, setQuantities] = useState({});
  const [selectedProducts, setSelectedProducts] = useState([]); // This state doesn't seem to be used. You might remove it if not needed.

  const updateQuantity = (productId, change) => {
    setQuantities(prev => ({
      ...prev,
      [productId]: Math.max(0, (prev[productId] || 0) + change)
    }));
  };

  const setDirectQuantity = (productId, value) => {
    const numValue = parseInt(value) || 0;
    setQuantities(prev => ({
      ...prev,
      [productId]: Math.max(0, numValue)
    }));
  };

  const addProductToCart = (product) => {
    const quantity = quantities[product.id] || 0;
    if (quantity > 0) {
      if (quantity > product.available) {
        alert(`Sorry, only ${product.available} kg available in stock!`);
        return;
      }
      
      onAddToCart(product, quantity);
      setQuantities(prev => ({ ...prev, [product.id]: 0 }));
      
      // Success notification
      const toast = document.createElement('div');
      toast.className = 'alert alert-success position-fixed';
      toast.style.cssText = 'top: 100px; right: 20px; z-index: 9999; min-width: 300px;';
      toast.innerHTML = `
        <i class="fas fa-check-circle me-2"></i>
        Added ${quantity} kg of ${product.name} to cart!
      `;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 3000);
    } else {
      alert('Please select a quantity greater than 0');
    }
  };

  const calculateDiscount = (product, quantity) => {
    return quantity >= product.minBulk ? product.discount : 0;
  };

  const calculateTotal = (product, quantity) => {
    const subtotal = product.price * quantity;
    const discount = calculateDiscount(product, quantity);
    return subtotal - (subtotal * discount / 100);
  };

  if (!supplier) {
    return (
      <div className="container-fluid py-5">
        <div className="text-center">
          <i className="fas fa-exclamation-triangle fs-1 text-warning mb-3"></i>
          <h3>Supplier not found</h3>
          <button 
            className="btn btn-primary"
            onClick={() => onViewChange('vendorDashboard')}
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4 bg-light min-vh-100">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-12">
            {/* Header Card */}
            <div className="card shadow border-0 mb-4">
              <div className="card-header bg-primary text-white">
                <div className="d-flex justify-content-between align-items-center">
                  <div className="d-flex align-items-center">
                    <div className="avatar-lg bg-white text-primary rounded-circle d-flex align-items-center justify-content-center me-3">
                      <i className="fas fa-store fs-3"></i>
                    </div>
                    <div>
                      <h3 className="mb-1 fw-bold">{supplier.name}</h3>
                      <p className="mb-0 opacity-75">
                        <i className="fas fa-map-marker-alt me-2"></i>
                        {supplier.location}
                      </p>
                    </div>
                  </div>
                  <button 
                    className="btn btn-outline-light"
                    onClick={() => onViewChange('vendorDashboard')}
                  >
                    <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
                  </button>
                </div>
              </div>
              
              {/* Supplier Info */}
              <div className="card-body">
                <div className="row">
                  <div className="col-md-8">
                    <div className="row g-4">
                      <div className="col-sm-6">
                        <div className="d-flex align-items-center">
                          <i className="fas fa-phone fs-4 text-primary me-3"></i>
                          <div>
                            <h6 className="mb-1 fw-bold">Contact Number</h6>
                            <p className="mb-0 text-muted">{supplier.contact}</p>
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="d-flex align-items-center">
                          <i className="fas fa-star fs-4 text-warning me-3"></i>
                          <div>
                            <h6 className="mb-1 fw-bold">Rating</h6>
                            <div className="d-flex align-items-center">
                              <span className="me-2">{supplier.rating}</span>
                              <div className="stars">
                                {[1,2,3,4,5].map(star => (
                                  <i 
                                    key={star}
                                    className={`fas fa-star ${star <= supplier.rating ? 'text-warning' : 'text-muted'}`}
                                  ></i>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="d-flex align-items-center">
                          <i className="fas fa-box fs-4 text-success me-3"></i>
                          <div>
                            <h6 className="mb-1 fw-bold">Products Available</h6>
                            <p className="mb-0 text-muted">{supplier.products.length} Products</p>
                          </div>
                        </div>
                      </div>
                      <div className="col-sm-6">
                        <div className="d-flex align-items-center">
                          <i className={`fas fa-${supplier.verified ? 'check-circle' : 'clock'} fs-4 ${supplier.verified ? 'text-success' : 'text-warning'} me-3`}></i>
                          <div>
                            <h6 className="mb-1 fw-bold">Verification Status</h6>
                            <span className={`badge bg-${supplier.verified ? 'success' : 'warning'}`}>
                              {supplier.verified ? 'Verified' : 'Pending'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="card bg-light h-100">
                      <div className="card-body d-flex align-items-center justify-content-center">
                        <div className="text-center text-muted">
                          <i className="fas fa-map fs-1 mb-2"></i>
                          <p className="mb-0">Location Map</p>
                          <small>Integration Coming Soon</small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Products Section */}
            <div className="card shadow border-0">
              <div className="card-header bg-white border-bottom">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="mb-0 fw-bold">
                    <i className="fas fa-shopping-basket me-2 text-primary"></i>
                    Available Products
                  </h5>
                  <span className="badge bg-light text-dark">{supplier.products.length} Products</span>
                </div>
              </div>
              
              <div className="card-body p-0">
                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead className="table-dark">
                      <tr>
                        <th className="border-0">Product</th>
                        <th className="border-0">Price/kg</th>
                        <th className="border-0">Available Stock</th>
                        <th className="border-0">Bulk Offer</th>
                        <th className="border-0">Quantity (kg)</th>
                        <th className="border-0">Estimated Total</th>
                        <th className="border-0">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {supplier.products.map(product => {
                        const quantity = quantities[product.id] || 0;
                        const discount = calculateDiscount(product, quantity);
                        const total = calculateTotal(product, quantity);
                        
                        return (
                          <tr key={product.id} className="product-row">
                            <td>
                              <div className="d-flex align-items-center">
                                <div className="product-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                                  <i className="fas fa-seedling"></i>
                                </div>
                                <div>
                                  <h6 className="mb-0 fw-bold">{product.name}</h6>
                                  <small className="text-muted">Fresh Quality</small>
                                </div>
                              </div>
                            </td>
                            <td>
                              <span className="fw-bold text-success">${product.price}</span>
                            </td>
                            <td>
                              <span className={`badge ${product.available > 100 ? 'bg-success' : product.available > 50 ? 'bg-warning' : 'bg-danger'}`}>
                                {product.available} kg
                              </span>
                            </td>
                            <td>
                              <div className="small">
                                <div><strong>Min:</strong> {product.minBulk} kg</div>
                                <div className="text-success"><strong>Discount:</strong> {product.discount}%</div>
                              </div>
                            </td>
                            <td>
                              <div className="input-group quantity-control">
                                <button 
                                  className="btn btn-outline-secondary btn-sm"
                                  onClick={() => updateQuantity(product.id, -1)}
                                  disabled={quantity <= 0}
                                >
                                  <i className="fas fa-minus"></i>
                                </button>
                                <input 
                                  type="number" 
                                  className="form-control form-control-sm text-center"
                                  value={quantity}
                                  onChange={(e) => setDirectQuantity(product.id, e.target.value)}
                                  min="0"
                                  max={product.available}
                                  style={{maxWidth: '80px'}}
                                />
                                <button 
                                  className="btn btn-outline-secondary btn-sm"
                                  onClick={() => updateQuantity(product.id, 1)}
                                  disabled={quantity >= product.available}
                                >
                                  <i className="fas fa-plus"></i>
                                </button>
                              </div>
                              {quantity >= product.minBulk && (
                                <small className="text-success d-block mt-1">
                                  <i className="fas fa-tag me-1"></i>
                                  Bulk discount applied!
                                </small>
                              )}
                            </td>
                            <td>
                              {quantity > 0 && (
                                <div>
                                  <div className="fw-bold text-primary">${total.toFixed(2)}</div>
                                  {discount > 0 && (
                                    <small className="text-success">
                                      Save ${((product.price * quantity) - total).toFixed(2)}
                                    </small>
                                  )}
                                </div>
                              )}
                            </td>
                            <td>
                              <button 
                                className="btn btn-success btn-sm"
                                onClick={() => addProductToCart(product)}
                                disabled={quantity === 0}
                              >
                                <i className="fas fa-cart-plus me-1"></i>
                                Add to Cart
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Additional Info */}
            <div className="row mt-4">
              <div className="col-md-6">
                <div className="card border-0 shadow-sm">
                  <div className="card-body">
                    <h6 className="fw-bold mb-3">
                      <i className="fas fa-info-circle me-2 text-info"></i>
                      Bulk Purchase Benefits
                    </h6>
                    <ul className="list-unstyled">
                      <li className="mb-2">
                        <i className="fas fa-check text-success me-2"></i>
                        Automatic discounts on bulk orders
                      </li>
                      <li className="mb-2">
                        <i className="fas fa-check text-success me-2"></i>
                        Priority delivery service
                      </li>
                      <li className="mb-2">
                        <i className="fas fa-check text-success me-2"></i>
                        Quality guarantee on all products
                      </li>
                      <li className="mb-0">
                        <i className="fas fa-check text-success me-2"></i>
                        24/7 customer support
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card border-0 shadow-sm">
                  <div className="card-body">
                    <h6 className="fw-bold mb-3">
                      <i className="fas fa-shipping-fast me-2 text-primary"></i>
                      Delivery Information
                    </h6>
                    <ul className="list-unstyled">
                      <li className="mb-2">
                        <i className="fas fa-truck text-primary me-2"></i>
                        Free delivery on orders above $50
                      </li>
                      <li className="mb-2">
                        <i className="fas fa-clock text-warning me-2"></i>
                        Standard delivery: 2-3 business days
                      </li>
                      <li className="mb-2">
                        <i className="fas fa-bolt text-success me-2"></i>
                        Express delivery available
                      </li>
                      <li className="mb-0">
                        <i className="fas fa-shield-alt text-info me-2"></i>
                        Secure packaging guaranteed
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Styles */}
      <style>{`
        .avatar-lg {
          width: 60px;
          height: 60px;
        }
        
        .product-icon {
          width: 40px;
          height: 40px;
          font-size: 1.2rem;
        }
        
        .product-row:hover {
          background-color: rgba(0,123,255,0.05);
        }
        
        .quantity-control {
          max-width: 140px;
        }
        
        .stars i {
          font-size: 0.9rem;
        }
        
        .table th {
          font-weight: 600;
          font-size: 0.9rem;
        }
      `}</style>
    </div>
  );
};

export default SupplierDetailsPage;