// components/SupplierDashboard.js - Enhanced with Real-time Features
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useRealtime, useRealtimeProducts, useRealtimeOrders } from '../contexts/RealtimeContext';

const SupplierDashboard = ({ currentUser, onViewChange }) => {
  const { isConnected, addNotification, connectSocket } = useRealtime();
  const { products, setProducts } = useRealtimeProducts();
  const { orders } = useRealtimeOrders();
  
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    available: '',
    minBulk: '10',
    discount: '0',
    category: '',
    description: ''
  });
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [addingProduct, setAddingProduct] = useState(false);

  const categories = ['Grains', 'Pulses', 'Spices', 'Oil', 'Sugar', 'Rice', 'Wheat', 'Other'];

  useEffect(() => {
    // Connect to WebSocket when component mounts
    const token = localStorage.getItem('token');
    if (token) {
      connectSocket(token);
    }
    
    fetchDashboardData();
  }, []);

  // Real-time connection status indicator
  const ConnectionStatus = () => (
    <div className={`badge ${isConnected ? 'bg-success' : 'bg-danger'} position-fixed`} 
         style={{top: '80px', right: '20px', zIndex: 1050}}>
      <i className={`fas fa-${isConnected ? 'wifi' : 'exclamation-triangle'} me-1`}></i>
      {isConnected ? 'Live' : 'Offline'}
    </div>
  );

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      // Fetch products and stats
      const [productsRes, statsRes] = await Promise.all([
        axios.get(`http://localhost:5000/api/products?supplierId=${currentUser.id}`, { headers }),
        axios.get('http://localhost:5000/api/dashboard/stats', { headers })
      ]);

      setProducts(productsRes.data);
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      addNotification('Failed to load dashboard data', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    setAddingProduct(true);
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post('http://localhost:5000/api/products', newProduct, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // Update local products state (real-time hook will also update)
      setProducts(prev => [...prev, response.data]);
      
      // Reset form
      setNewProduct({
        name: '', price: '', available: '', minBulk: '10', 
        discount: '0', category: '', description: ''
      });
      setShowAddProduct(false);
      
      addNotification(
        `Product "${response.data.name}" added successfully! All vendors have been notified.`, 
        'success', 
        5000
      );
      
      // Refresh stats
      const statsRes = await axios.get('http://localhost:5000/api/dashboard/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStats(statsRes.data);
      
    } catch (error) {
      console.error('Error adding product:', error);
      addNotification('Failed to add product. Please try again.', 'error');
    } finally {
      setAddingProduct(false);
    }
  };

  const handleEditProduct = async (productId, updatedProduct) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.put(`http://localhost:5000/api/products/${productId}`, updatedProduct, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setProducts(products.map(p => p._id === productId ? response.data : p));
      setEditingProduct(null);
      
      addNotification(
        `Product "${response.data.name}" updated successfully! All vendors have been notified.`, 
        'success', 
        4000
      );
    } catch (error) {
      console.error('Error updating product:', error);
      addNotification('Failed to update product. Please try again.', 'error');
    }
  };

  const handleOrderStatusUpdate = async (orderId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`http://localhost:5000/api/orders/${orderId}/status`, 
        { status: newStatus }, 
        { headers: { Authorization: `Bearer ${token}` }}
      );

      addNotification(
        `Order #${orderId} status updated to ${newStatus}. Vendor has been notified.`, 
        'success', 
        4000
      );
    } catch (error) {
      console.error('Error updating order status:', error);
      addNotification('Failed to update order status. Please try again.', 'error');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'warning',
      confirmed: 'info',
      processing: 'primary',
      shipped: 'secondary',
      delivered: 'success',
      cancelled: 'danger'
    };
    return colors[status] || 'secondary';
  };

  if (loading && products.length === 0) {
    return (
      <div className="min-vh-100 d-flex align-items-center justify-content-center">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4">
      <ConnectionStatus />
      
      {/* Header */}
      <div className="row mb-4">
        <div className="col">
          <h2 className="fw-bold text-primary mb-1">
            <i className="fas fa-truck me-2"></i>Supplier Dashboard
            {isConnected && (
              <span className="badge bg-success ms-2 fs-6">
                <i className="fas fa-broadcast-tower me-1"></i>Broadcasting Live
              </span>
            )}
          </h2>
          <p className="text-muted">Welcome back, {currentUser.name}!</p>
        </div>
      </div>

      {/* Enhanced Stats Cards with Real-time Data */}
      <div className="row mb-4">
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-primary text-white">
            <div className="card-body">
              <i className="fas fa-box-open fa-2x mb-2"></i>
              <h3 className="fw-bold">{products.length || 0}</h3>
              <p className="mb-1">Active Products</p>
              <small className="opacity-75">
                <i className="fas fa-sync-alt me-1"></i>Live count
              </small>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-success text-white">
            <div className="card-body">
              <i className="fas fa-shopping-cart fa-2x mb-2"></i>
              <h3 className="fw-bold">{orders.length || 0}</h3>
              <p className="mb-1">Total Orders</p>
              <small className="opacity-75">Real-time tracking</small>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-warning text-white">
            <div className="card-body">
              <i className="fas fa-clock fa-2x mb-2"></i>
              <h3 className="fw-bold">
                {orders.filter(order => order.status === 'pending').length || 0}
              </h3>
              <p className="mb-1">Pending Orders</p>
              <small className="opacity-75">
                <i className="fas fa-bell me-1"></i>Live alerts
              </small>
            </div>
          </div>
        </div>
        <div className="col-lg-3 col-md-6 mb-3">
          <div className="card border-0 shadow-sm h-100 text-center bg-gradient-info text-white">
            <div className="card-body">
              <i className="fas fa-rupee-sign fa-2x mb-2"></i>
              <h3 className="fw-bold">
                ₹{orders.reduce((sum, order) => sum + (order.total || 0), 0).toFixed(2)}
              </h3>
              <p className="mb-1">Total Revenue</p>
              <small className="opacity-75">Live calculation</small>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="row mb-4">
        <div className="col">
          <ul className="nav nav-pills">
            <li className="nav-item">
              <button 
                className={`nav-link ${activeTab === 'overview' ? 'active' : ''}`}
                onClick={() => setActiveTab('overview')}
              >
                <i className="fas fa-chart-line me-2"></i>Overview
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link ${activeTab === 'products' ? 'active' : ''}`}
                onClick={() => setActiveTab('products')}
              >
                <i className="fas fa-box me-2"></i>Products
                <span className="badge bg-light text-dark ms-1">{products.length}</span>
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => setActiveTab('orders')}
              >
                <i className="fas fa-list-alt me-2"></i>Orders
                <span className="badge bg-danger text-white ms-1">
                  {orders.filter(order => order.status === 'pending').length}
                </span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Overview Tab with Real-time Activity */}
      {activeTab === 'overview' && (
        <div className="row">
          <div className="col-lg-8">
            <div className="card border-0 shadow-sm">
              <div className="card-header bg-white d-flex justify-content-between align-items-center">
                <h5 className="mb-0"><i className="fas fa-chart-bar me-2"></i>Recent Activity</h5>
                <span className="badge bg-success">
                  <i className="fas fa-circle me-1"></i>Live Feed
                </span>
              </div>
              <div className="card-body">
                {orders.slice(0, 5).map(order => (
                  <div key={order._id} className="d-flex align-items-center mb-3 pb-3 border-bottom animate-activity">
                    <div className="activity-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                      <i className="fas fa-shopping-cart"></i>
                    </div>
                    <div className="flex-grow-1">
                      <h6 className="mb-1">Order #{order.orderId}</h6>
                      <p className="text-muted mb-1">
                        {order.vendorId?.name} • {order.items?.length || 0} items • ₹{order.total}
                      </p>
                      <small className="text-muted">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </small>
                    </div>
                    <span className={`badge bg-${getStatusColor(order.status)} pulse-badge`}>
                      {order.status}
                    </span>
                  </div>
                ))}
                {orders.length === 0 && (
                  <div className="text-center py-4">
                    <i className="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <p className="text-muted">No orders yet - waiting for vendors...</p>
                    <div className="d-flex justify-content-center">
                      <div className="spinner-grow text-primary spinner-grow-sm me-2"></div>
                      <div className="spinner-grow text-success spinner-grow-sm me-2"></div>
                      <div className="spinner-grow text-info spinner-grow-sm"></div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="col-lg-4">
            <div className="card border-0 shadow-sm">
              <div className="card-header bg-white">
                <h5 className="mb-0"><i className="fas fa-star me-2"></i>Your Products</h5>
              </div>
              <div className="card-body">
                {products.slice(0, 5).map(product => (
                  <div key={product._id} className="d-flex align-items-center mb-3 product-item">
                    <div className="product-icon bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                      <i className="fas fa-seedling"></i>
                    </div>
                    <div className="flex-grow-1">
                      <h6 className="mb-1">{product.name}</h6>
                      <p className="text-muted mb-0">
                        ₹{product.price} • {product.available} in stock
                      </p>
                    </div>
                    <span className="badge bg-success">
                      {product.discount}% off
                    </span>
                  </div>
                ))}
                {products.length === 0 && (
                  <div className="text-center py-4">
                    <i className="fas fa-box fa-3x text-muted mb-3"></i>
                    <p className="text-muted">No products added yet</p>
                    <button 
                      className="btn btn-primary btn-sm"
                      onClick={() => {
                        setActiveTab('products');
                        setShowAddProduct(true);
                      }}
                    >
                      <i className="fas fa-plus me-1"></i>Add Your First Product
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Products Tab */}
      {activeTab === 'products' && (
        <div>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h4>Manage Products</h4>
            <button 
              className="btn btn-primary"
              onClick={() => setShowAddProduct(true)}
              disabled={addingProduct}
            >
              {addingProduct ? (
                <><i className="fas fa-spinner fa-spin me-2"></i>Adding...</>
              ) : (
                <><i className="fas fa-plus me-2"></i>Add New Product</>
              )}
            </button>
          </div>

          {/* Enhanced Add Product Modal */}
          {showAddProduct && (
            <div className="modal show d-block" style={{backgroundColor: 'rgba(0,0,0,0.5)'}}>
              <div className="modal-dialog modal-lg">
                <div className="modal-content">
                  <div className="modal-header bg-primary text-white">
                    <h5 className="modal-title">
                      <i className="fas fa-plus-circle me-2"></i>Add New Product
                    </h5>
                    <button 
                      className="btn-close btn-close-white"
                      onClick={() => setShowAddProduct(false)}
                      disabled={addingProduct}
                    ></button>
                  </div>
                  <form onSubmit={handleAddProduct}>
                    <div className="modal-body">
                      <div className="alert alert-info">
                        <i className="fas fa-info-circle me-2"></i>
                        Adding a product will instantly notify all vendors in real-time!
                      </div>
                      
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Product Name *</label>
                          <input 
                            type="text"
                            className="form-control"
                            value={newProduct.name}
                            onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                            required
                            disabled={addingProduct}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Category *</label>
                          <select 
                            className="form-control"
                            value={newProduct.category}
                            onChange={(e) => setNewProduct({...newProduct, category: e.target.value})}
                            required
                            disabled={addingProduct}
                          >
                            <option value="">Select Category</option>
                            {categories.map(cat => (
                              <option key={cat} value={cat}>{cat}</option>
                            ))}
                          </select>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Price per unit (₹) *</label>
                          <input 
                            type="number"
                            step="0.01"
                            className="form-control"
                            value={newProduct.price}
                            onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                            required
                            disabled={addingProduct}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Available Quantity *</label>
                          <input 
                            type="number"
                            className="form-control"
                            value={newProduct.available}
                            onChange={(e) => setNewProduct({...newProduct, available: e.target.value})}
                            required
                            disabled={addingProduct}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Minimum Bulk Order</label>
                          <input 
                            type="number"
                            className="form-control"
                            value={newProduct.minBulk}
                            onChange={(e) => setNewProduct({...newProduct, minBulk: e.target.value})}
                            disabled={addingProduct}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Bulk Discount (%)</label>
                          <input 
                            type="number"
                            max="100"
                            className="form-control"
                            value={newProduct.discount}
                            onChange={(e) => setNewProduct({...newProduct, discount: e.target.value})}
                            disabled={addingProduct}
                          />
                        </div>
                        <div className="col-12 mb-3">
                          <label className="form-label">Description</label>
                          <textarea 
                            className="form-control"
                            rows="3"
                            value={newProduct.description}
                            onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                            placeholder="Describe your product..."
                            disabled={addingProduct}
                          ></textarea>
                        </div>
                      </div>
                    </div>
                    <div className="modal-footer">
                      <button 
                        type="button"
                        className="btn btn-secondary"
                        onClick={() => setShowAddProduct(false)}
                        disabled={addingProduct}
                      >
                        Cancel
                      </button>
                      <button type="submit" className="btn btn-primary" disabled={addingProduct}>
                        {addingProduct ? (
                          <><i className="fas fa-spinner fa-spin me-2"></i>Adding Product...</>
                        ) : (
                          <><i className="fas fa-broadcast-tower me-2"></i>Add & Broadcast</>
                        )}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* Products Grid with Real-time Updates */}
          <div className="row">
            {products.map(product => (
              <div key={product._id} className="col-lg-4 col-md-6 mb-4">
                <div className="card border-0 shadow-sm h-100 product-card">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-start mb-3">
                      <h5 className="card-title">{product.name}</h5>
                      <div className="dropdown">
                        <button 
                          className="btn btn-sm btn-outline-secondary dropdown-toggle"
                          data-bs-toggle="dropdown"
                        >
                          <i className="fas fa-ellipsis-v"></i>
                        </button>
                        <ul className="dropdown-menu">
                          <li>
                            <button 
                              className="dropdown-item"
                              onClick={() => setEditingProduct(product)}
                            >
                              <i className="fas fa-edit me-2"></i>Edit & Broadcast
                            </button>
                          </li>
                          <li>
                            <button className="dropdown-item text-danger">
                              <i className="fas fa-trash me-2"></i>Delete
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <p className="text-muted mb-2">
                      <span className="badge bg-light text-dark">{product.category}</span>
                    </p>
                    <p className="card-text">{product.description}</p>
                    <div className="row text-center">
                      <div className="col-4">
                        <small className="text-muted">Price</small>
                        <div className="fw-bold text-success">₹{product.price}</div>
                      </div>
                      <div className="col-4">
                        <small className="text-muted">Stock</small>
                        <div className={`fw-bold ${product.available < 10 ? 'text-danger' : 'text-primary'}`}>
                          {product.available}
                        </div>
                      </div>
                      <div className="col-4">
                        <small className="text-muted">Discount</small>
                        <div className="fw-bold text-warning">{product.discount}%</div>
                      </div>
                    </div>
                  </div>
                  <div className="card-footer bg-light">
                    <small className="text-muted">
                      <i className="fas fa-eye me-1"></i>
                      Visible to all vendors • 
                      <i className="fas fa-clock ms-2 me-1"></i>
                      Updated {new Date(product.updatedAt).toLocaleDateString()}
                    </small>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {products.length === 0 && (
            <div className="text-center py-5">
              <i className="fas fa-box-open fa-4x text-muted mb-3"></i>
              <h5>No Products Added Yet</h5>
              <p className="text-muted">Add your first product to start receiving orders from vendors</p>
              <button 
                className="btn btn-primary btn-lg"
                onClick={() => setShowAddProduct(true)}
              >
                <i className="fas fa-plus me-2"></i>Add Your First Product
              </button>
            </div>
          )}
        </div>
      )}

      {/* Real-time Orders Tab */}
      {activeTab === 'orders' && (
        <div>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h4>Manage Orders</h4>
            <div className="d-flex align-items-center gap-3">
              <span className="badge bg-info">
                <i className="fas fa-sync-alt me-1"></i>Real-time Updates
              </span>
              <span className="text-muted">
                {orders.filter(order => order.status === 'pending').length} pending
              </span>
            </div>
          </div>
          
          <div className="card border-0 shadow-sm">
            <div className="card-body">
              {orders.length > 0 ? (
                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead className="table-dark">
                      <tr>
                        <th>Order ID</th>
                        <th>Vendor</th><th>Items</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map(order => (
                        <tr key={order._id} className="order-row">
                          <td>
                            <strong>#{order.orderId}</strong>
                          </td>
                          <td>
                            <div className="d-flex align-items-center">
                              <div className="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                {order.vendorId?.name?.charAt(0) || 'V'}
                              </div>
                              <div>
                                <div className="fw-medium">{order.vendorId?.name || 'Unknown Vendor'}</div>
                                <small className="text-muted">{order.vendorId?.email}</small>
                              </div>
                            </div>
                          </td>
                          <td>
                            <div className="items-preview">
                              {order.items?.slice(0, 2).map((item, idx) => (
                                <div key={idx} className="small">
                                  {item.productId?.name} × {item.quantity}
                                </div>
                              ))}
                              {order.items?.length > 2 && (
                                <small className="text-muted">
                                  +{order.items.length - 2} more items
                                </small>
                              )}
                            </div>
                          </td>
                          <td>
                            <div className="fw-bold text-success">₹{order.total?.toFixed(2)}</div>
                          </td>
                          <td>
                            <span className={`badge bg-${getStatusColor(order.status)} pulse-badge`}>
                              {order.status}
                            </span>
                          </td>
                          <td>
                            <div>{new Date(order.createdAt).toLocaleDateString()}</div>
                            <small className="text-muted">
                              {new Date(order.createdAt).toLocaleTimeString()}
                            </small>
                          </td>
                          <td>
                            <div className="dropdown">
                              <button 
                                className="btn btn-sm btn-outline-primary dropdown-toggle"
                                data-bs-toggle="dropdown"
                              >
                                Update Status
                              </button>
                              <ul className="dropdown-menu">
                                {['pending', 'confirmed', 'processing', 'shipped', 'delivered'].map(status => (
                                  <li key={status}>
                                    <button 
                                      className="dropdown-item"
                                      onClick={() => handleOrderStatusUpdate(order._id, status)}
                                      disabled={order.status === status}
                                    >
                                      <i className={`fas fa-${
                                        status === 'pending' ? 'clock' :
                                        status === 'confirmed' ? 'check' :
                                        status === 'processing' ? 'cog' :
                                        status === 'shipped' ? 'truck' :
                                        'check-double'
                                      } me-2`}></i>
                                      {status.charAt(0).toUpperCase() + status.slice(1)}
                                    </button>
                                  </li>
                                ))}
                                <li><hr className="dropdown-divider" /></li>
                                <li>
                                  <button 
                                    className="dropdown-item text-danger"
                                    onClick={() => handleOrderStatusUpdate(order._id, 'cancelled')}
                                  >
                                    <i className="fas fa-times me-2"></i>Cancel Order
                                  </button>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-5">
                  <i className="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
                  <h5>No Orders Yet</h5>
                  <p className="text-muted">
                    Orders from vendors will appear here in real-time
                  </p>
                  <div className="d-flex justify-content-center mt-3">
                    <div className="spinner-grow text-primary spinner-grow-sm me-2"></div>
                    <div className="spinner-grow text-success spinner-grow-sm me-2"></div>
                    <div className="spinner-grow text-info spinner-grow-sm"></div>
                  </div>
                  <p className="text-muted mt-2">Waiting for incoming orders...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="modal show d-block" style={{backgroundColor: 'rgba(0,0,0,0.5)'}}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header bg-warning text-dark">
                <h5 className="modal-title">
                  <i className="fas fa-edit me-2"></i>Edit Product - {editingProduct.name}
                </h5>
                <button 
                  className="btn-close"
                  onClick={() => setEditingProduct(null)}
                ></button>
              </div>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const updatedProduct = {
                  name: formData.get('name'),
                  category: formData.get('category'),
                  price: formData.get('price'),
                  available: formData.get('available'),
                  minBulk: formData.get('minBulk'),
                  discount: formData.get('discount'),
                  description: formData.get('description')
                };
                handleEditProduct(editingProduct._id, updatedProduct);
              }}>
                <div className="modal-body">
                  <div className="alert alert-warning">
                    <i className="fas fa-broadcast-tower me-2"></i>
                    Updating this product will instantly notify all vendors!
                  </div>
                  
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Product Name *</label>
                      <input 
                        type="text"
                        name="name"
                        className="form-control"
                        defaultValue={editingProduct.name}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Category *</label>
                      <select 
                        name="category"
                        className="form-control"
                        defaultValue={editingProduct.category}
                        required
                      >
                        <option value="">Select Category</option>
                        {categories.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Price per unit (₹) *</label>
                      <input 
                        type="number"
                        step="0.01"
                        name="price"
                        className="form-control"
                        defaultValue={editingProduct.price}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Available Quantity *</label>
                      <input 
                        type="number"
                        name="available"
                        className="form-control"
                        defaultValue={editingProduct.available}
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Minimum Bulk Order</label>
                      <input 
                        type="number"
                        name="minBulk"
                        className="form-control"
                        defaultValue={editingProduct.minBulk}
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Bulk Discount (%)</label>
                      <input 
                        type="number"
                        max="100"
                        name="discount"
                        className="form-control"
                        defaultValue={editingProduct.discount}
                      />
                    </div>
                    <div className="col-12 mb-3">
                      <label className="form-label">Description</label>
                      <textarea 
                        name="description"
                        className="form-control"
                        rows="3"
                        defaultValue={editingProduct.description}
                        placeholder="Describe your product..."
                      ></textarea>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button 
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setEditingProduct(null)}
                  >
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-warning">
                    <i className="fas fa-broadcast-tower me-2"></i>Update & Broadcast
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Custom Styles */}
      <style jsx>{`
        .bg-gradient-primary {
          background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
        }
        
        .bg-gradient-success {
          background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
        }
        
        .bg-gradient-warning {
          background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
        }
        
        .bg-gradient-info {
          background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
        }
        
        .product-card {
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .product-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        
        .activity-icon, .product-icon {
          width: 40px;
          height: 40px;
          font-size: 14px;
        }
        
        .avatar-sm {
          width: 32px;
          height: 32px;
          font-size: 12px;
        }
        
        .pulse-badge {
          animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
          0% { opacity: 1; }
          50% { opacity: 0.7; }
          100% { opacity: 1; }
        }
        
        .animate-activity {
          animation: slideInRight 0.3s ease-out;
        }
        
        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        
        .order-row {
          transition: background-color 0.2s ease;
        }
        
        .order-row:hover {
          background-color: rgba(0,123,255,0.05);
        }
        
        .items-preview {
          max-width: 150px;
        }
        
        .spinner-grow {
          animation-duration: 1.5s;
        }
        
        .badge.bg-success {
          animation: glow 2s ease-in-out infinite alternate;
        }
        
        @keyframes glow {
          from { box-shadow: 0 0 5px rgba(40, 167, 69, 0.5); }
          to { box-shadow: 0 0 10px rgba(40, 167, 69, 0.8); }
        }
      `}</style>
    </div>
  );
};

export default SupplierDashboard;