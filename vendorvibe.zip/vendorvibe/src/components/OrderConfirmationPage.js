// components/OrderConfirmationPage.js
import React, { useState, useEffect } from 'react';

const OrderConfirmationPage = ({ orders, onViewChange }) => {
  const [supplier, setSupplier] = useState('');
  const [trackingStage, setTrackingStage] = useState(0);
  
  const latestOrder = orders[orders.length - 1];

  // Simulate order progression
  useEffect(() => {
    if (latestOrder) {
      const progressStages = [
        { stage: 0, delay: 0 },
        { stage: 1, delay: 3000 },
        { stage: 2, delay: 8000 }
      ];

      progressStages.forEach(({ stage, delay }) => {
        setTimeout(() => setTrackingStage(stage), delay);
      });
    }
  }, [latestOrder]);

  const trackingSteps = [
    {
      id: 'received',
      title: 'Order Received',
      description: 'Your order has been confirmed',
      icon: 'fas fa-check-circle',
      color: 'success'
    },
    {
      id: 'processing',
      title: 'Collecting Materials',
      description: 'Supplier is preparing your order',
      icon: 'fas fa-box-open',
      color: 'warning'
    },
    {
      id: 'shipping',
      title: 'Out for Delivery',
      description: 'Your order is on the way',
      icon: 'fas fa-shipping-fast',
      color: 'info'
    },
    {
      id: 'delivered',
      title: 'Delivered',
      description: 'Order successfully delivered',
      icon: 'fas fa-home',
      color: 'primary'
    }
  ];

  if (!latestOrder) {
    return (
      <div className="container-fluid py-5 bg-light min-vh-100">
        <div className="text-center">
          <i className="fas fa-exclamation-triangle fs-1 text-warning mb-3"></i>
          <h3>No order found</h3>
          <button 
            className="btn btn-primary"
            onClick={() => onViewChange('vendorDashboard')}
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4 bg-light min-vh-100">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-10">
            {/* Success Header */}
            <div className="card shadow border-0 mb-4">
              <div className="card-header bg-success text-white text-center py-4">
                <div className="mb-3">
                  <i className="fas fa-check-circle fs-1"></i>
                </div>
                <h2 className="mb-2 fw-bold">Order Placed Successfully!</h2>
                <p className="mb-0 fs-5">Thank you for your order. We're processing it now.</p>
              </div>
            </div>

            <div className="row">
              {/* Order Details */}
              <div className="col-lg-8 mb-4">
                <div className="card shadow border-0 mb-4">
                  <div className="card-header bg-white border-bottom">
                    <h5 className="mb-0 fw-bold">
                      <i className="fas fa-receipt me-2 text-primary"></i>
                      Order Details
                    </h5>
                  </div>
                  <div className="card-body">
                    <div className="row mb-4">
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label fw-semibold text-muted">Order ID</label>
                          <div className="fs-5 fw-bold text-primary">#{latestOrder.id}</div>
                        </div>
                        <div className="mb-3">
                          <label className="form-label fw-semibold text-muted">Order Date</label>
                          <div className="fw-bold">{new Date(latestOrder.date).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}</div>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label fw-semibold text-muted">Supplier Name</label>
                          <input 
                            type="text" 
                            className="form-control"
                            value={supplier}
                            onChange={(e) => setSupplier(e.target.value)}
                            placeholder="Enter supplier name (optional)"
                          />
                        </div>
                        <div className="mb-3">
                          <label className="form-label fw-semibold text-muted">Order Total</label>
                          <div className="fs-4 fw-bold text-success">${latestOrder.total?.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>

                    {/* Order Items */}
                    <h6 className="fw-bold mb-3">Ordered Items</h6>
                    <div className="table-responsive">
                      <table className="table table-hover">
                        <thead className="table-light">
                          <tr>
                            <th className="border-0">Product</th>
                            <th className="border-0">Quantity</th>
                            <th className="border-0">Price</th>
                            <th className="border-0">Subtotal</th>
                          </tr>
                        </thead>
                        <tbody>
                          {latestOrder.items?.map(item => (
                            <tr key={item.id}>
                              <td>
                                <div className="d-flex align-items-center">
                                  <div className="product-icon bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                                    <i className="fas fa-seedling"></i>
                                  </div>
                                  <span className="fw-bold">{item.name}</span>
                                </div>
                              </td>
                              <td>{item.quantity} kg</td>
                              <td>${item.price}/kg</td>
                              <td className="fw-bold text-primary">${(item.price * item.quantity).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Order Tracking */}
                <div className="card shadow border-0">
                  <div className="card-header bg-white border-bottom">
                    <h5 className="mb-0 fw-bold">
                      <i className="fas fa-map-marker-alt me-2 text-info"></i>
                      Order Tracking
                    </h5>
                  </div>
                  <div className="card-body">
                    <div className="position-relative">
                      {/* Progress Line */}
                      <div className="progress-line position-absolute">
                        <div 
                          className="progress-fill bg-success"
                          style={{ 
                            width: `${(trackingStage / (trackingSteps.length - 1)) * 100}%`,
                            transition: 'width 1s ease-in-out'
                          }}
                        ></div>
                      </div>

                      {/* Tracking Steps */}
                      <div className="d-flex justify-content-between position-relative tracking-steps">
                        {trackingSteps.map((step, index) => {
                          const isCompleted = index <= trackingStage;
                          const isActive = index === trackingStage;
                          
                          return (
                            <div key={step.id} className="text-center tracking-step">
                              <div 
                                className={`step-circle mx-auto mb-3 d-flex align-items-center justify-content-center ${
                                  isCompleted ? `bg-${step.color} text-white` : 'bg-light text-muted border'
                                } ${isActive ? 'step-active' : ''}`}
                              >
                                <i className={step.icon}></i>
                              </div>
                              <h6 className={`fw-bold mb-1 ${isCompleted ? `text-${step.color}` : 'text-muted'}`}>
                                {step.title}
                              </h6>
                              <small className={isCompleted ? 'text-dark' : 'text-muted'}>
                                {step.description}
                              </small>
                              {isActive && (
                                <div className="mt-2">
                                  <span className="badge bg-primary">
                                    <i className="fas fa-clock me-1"></i>Current Status
                                  </span>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="alert alert-info mt-4">
                      <i className="fas fa-info-circle me-2"></i>
                      <strong>Estimated Delivery:</strong> 2-3 business days from order confirmation
                    </div>
                  </div>
                </div>
              </div>

              {/* Sidebar Actions */}
              <div className="col-lg-4">
                <div className="card shadow border-0 mb-4">
                  <div className="card-header bg-white">
                    <h6 className="mb-0 fw-bold">Quick Actions</h6>
                  </div>
                  <div className="card-body">
                    <div className="d-grid gap-3">
                      <button 
                        className="btn btn-primary"
                        onClick={() => onViewChange('vendorDashboard')}
                      >
                        <i className="fas fa-tachometer-alt me-2"></i>
                        Back to Dashboard
                      </button>
                      <button 
                        className="btn btn-outline-secondary"
                        onClick={() => onViewChange('pastOrders')}
                      >
                        <i className="fas fa-history me-2"></i>
                        View All Orders
                      </button>
                      <button className="btn btn-outline-info">
                        <i className="fas fa-download me-2"></i>
                        Download Invoice
                      </button>
                      <button className="btn btn-outline-success">
                        <i className="fas fa-share me-2"></i>
                        Share Order Details
                      </button>
                    </div>
                  </div>
                </div>

                {/* Order Summary */}
                <div className="card shadow border-0 mb-4">
                  <div className="card-header bg-white">
                    <h6 className="mb-0 fw-bold">Order Summary</h6>
                  </div>
                  <div className="card-body">
                    <div className="d-flex justify-content-between mb-2">
                      <span>Items ({latestOrder.items?.length}):</span>
                      <span>${latestOrder.total?.toFixed(2) || '0.00'}</span>
                    </div>
                    <div className="d-flex justify-content-between mb-2">
                      <span>Delivery:</span>
                      <span>Free</span>
                    </div>
                    <hr />
                    <div className="d-flex justify-content-between fw-bold">
                      <span>Total Paid:</span>
                      <span className="text-success">${latestOrder.total?.toFixed(2) || '0.00'}</span>
                    </div>
                  </div>
                </div>

                {/* Support Contact */}
                <div className="card shadow border-0">
                  <div className="card-header bg-white">
                    <h6 className="mb-0 fw-bold">Need Help?</h6>
                  </div>
                  <div className="card-body">
                    <p className="text-muted mb-3">
                      Contact our support team for any questions about your order.
                    </p>
                    <div className="d-grid gap-2">
                      <button className="btn btn-outline-primary btn-sm">
                        <i className="fas fa-phone me-2"></i>Call Support
                      </button>
                      <button className="btn btn-outline-success btn-sm">
                        <i className="fas fa-comments me-2"></i>Live Chat
                      </button>
                      <button className="btn btn-outline-info btn-sm">
                        <i className="fas fa-envelope me-2"></i>Email Us
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Styles */}
      <style jsx>{`
        .product-icon {
          width: 35px;
          height: 35px;
          font-size: 1rem;
        }
        
        .progress-line {
          top: 30px;
          left: 12.5%;
          right: 12.5%;
          height: 4px;
          background-color: #e9ecef;
          z-index: 1;
        }
        
        .progress-fill {
          height: 100%;
        }
        
        .tracking-steps {
          z-index: 2;
        }
        
        .tracking-step {
          flex: 1;
          max-width: 200px;
        }
        
        .step-circle {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          font-size: 1.5rem;
          position: relative;
          z-index: 3;
        }
        
        .step-active {
          animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
          0% { box-shadow: 0 0 0 0 rgba(0, 123, 255, 0.7); }
          70% { box-shadow: 0 0 0 10px rgba(0, 123, 255, 0); }
          100% { box-shadow: 0 0 0 0 rgba(0, 123, 255, 0); }
        }
      `}</style>
    </div>
  );
};

export default OrderConfirmationPage;