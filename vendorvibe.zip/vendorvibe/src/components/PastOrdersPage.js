// components/PastOrdersPage.js
import React, { useState } from 'react';

const PastOrdersPage = ({ orders, onViewChange }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date');

  // Filter and sort orders
  const filteredOrders = orders
    .filter(order => {
      const matchesSearch = order.id.toString().includes(searchTerm) || 
                           order.items?.some(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      switch(sortBy) {
        case 'date':
          return new Date(b.date) - new Date(a.date);
        case 'amount':
          return b.total - a.total;
        case 'status':
          return a.status.localeCompare(b.status);
        default:
          return 0;
      }
    });

  const getStatusBadge = (status) => {
    const statusConfig = {
      'pending': { class: 'warning', icon: 'clock', text: 'Pending' },
      'confirmed': { class: 'info', icon: 'check', text: 'Confirmed' },
      'processing': { class: 'primary', icon: 'cog', text: 'Processing' },
      'shipped': { class: 'info', icon: 'shipping-fast', text: 'Shipped' },
      'delivered': { class: 'success', icon: 'check-circle', text: 'Delivered' },
      'cancelled': { class: 'danger', icon: 'times', text: 'Cancelled' }
    };
    
    const config = statusConfig[status] || { class: 'secondary', icon: 'question', text: status };
    
    return (
      <span className={`badge bg-${config.class}`}>
        <i className={`fas fa-${config.icon} me-1`}></i>
        {config.text}
      </span>
    );
  };

  const calculateOrderStats = () => {
    const totalSpent = orders.reduce((sum, order) => sum + (order.total || 0), 0);
    const totalOrders = orders.length;
    const deliveredOrders = orders.filter(order => order.status === 'delivered').length;
    const avgOrderValue = totalOrders > 0 ? totalSpent / totalOrders : 0;

    return { totalSpent, totalOrders, deliveredOrders, avgOrderValue };
  };

  const stats = calculateOrderStats();

  if (orders.length === 0) {
    return (
      <div className="container-fluid py-5 bg-light min-vh-100">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <div className="card shadow border-0">
                <div className="card-body text-center py-5">
                  <div className="mb-4">
                    <i className="fas fa-history fs-1 text-muted mb-3"></i>
                    <h3 className="text-muted">No Order History</h3>
                    <p className="text-muted">You haven't placed any orders yet. Start shopping to see your order history here.</p>
                  </div>
                  <button 
                    className="btn btn-primary btn-lg"
                    onClick={() => onViewChange('vendorDashboard')}
                  >
                    <i className="fas fa-store me-2"></i>Start Shopping
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4 bg-light min-vh-100">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-12">
            {/* Header */}
            <div className="card shadow border-0 mb-4">
              <div className="card-header bg-primary text-white">
                <div className="d-flex justify-content-between align-items-center">
                  <h3 className="mb-0 fw-bold">
                    <i className="fas fa-history me-2"></i>
                    Order History
                  </h3>
                  <button 
                    className="btn btn-outline-light"
                    onClick={() => onViewChange('vendorDashboard')}
                  >
                    <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
                  </button>
                </div>
              </div>
            </div>

            <div className="row">
              {/* Stats Cards */}
              <div className="col-12 mb-4">
                <div className="row g-4">
                  <div className="col-md-3">
                    <div className="card bg-gradient-primary text-white h-100 shadow-sm">
                      <div className="card-body">
                        <div className="d-flex align-items-center">
                          <div className="flex-shrink-0">
                            <i className="fas fa-shopping-bag fs-3"></i>
                          </div>
                          <div className="flex-grow-1 ms-3">
                            <h6 className="card-title mb-1">Total Orders</h6>
                            <h3 className="fw-bold mb-0">{stats.totalOrders}</h3>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-3">
                    <div className="card bg-gradient-success text-white h-100 shadow-sm">
                      <div className="card-body">
                        <div className="d-flex align-items-center">
                          <div className="flex-shrink-0">
                            <i className="fas fa-dollar-sign fs-3"></i>
                          </div>
                          <div className="flex-grow-1 ms-3">
                            <h6 className="card-title mb-1">Total Spent</h6>
                            <h3 className="fw-bold mb-0">${stats.totalSpent.toFixed(2)}</h3>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-3">
                    <div className="card bg-gradient-info text-white h-100 shadow-sm">
                      <div className="card-body">
                        <div className="d-flex align-items-center">
                          <div className="flex-shrink-0">
                            <i className="fas fa-check-circle fs-3"></i>
                          </div>
                          <div className="flex-grow-1 ms-3">
                            <h6 className="card-title mb-1">Delivered</h6>
                            <h3 className="fw-bold mb-0">{stats.deliveredOrders}</h3>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-3">
                    <div className="card bg-gradient-warning text-white h-100 shadow-sm">
                      <div className="card-body">
                        <div className="d-flex align-items-center">
                          <div className="flex-shrink-0">
                            <i className="fas fa-chart-line fs-3"></i>
                          </div>
                          <div className="flex-grow-1 ms-3">
                            <h6 className="card-title mb-1">Avg Order</h6>
                            <h3 className="fw-bold mb-0">${stats.avgOrderValue.toFixed(2)}</h3>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Filters and Search */}
              <div className="col-12 mb-4">
                <div className="card shadow border-0">
                  <div className="card-body">
                    <div className="row g-3">
                      <div className="col-md-4">
                        <label className="form-label fw-semibold">Search Orders</label>
                        <div className="input-group">
                          <span className="input-group-text bg-light">
                            <i className="fas fa-search"></i>
                          </span>
                          <input 
                            type="text" 
                            className="form-control"
                            placeholder="Search by Order ID or Product"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="col-md-3">
                        <label className="form-label fw-semibold">Filter by Status</label>
                        <select 
                          className="form-select"
                          value={statusFilter}
                          onChange={(e) => setStatusFilter(e.target.value)}
                        >
                          <option value="all">All Status</option>
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="processing">Processing</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label className="form-label fw-semibold">Sort By</label>
                        <select 
                          className="form-select"
                          value={sortBy}
                          onChange={(e) => setSortBy(e.target.value)}
                        >
                          <option value="date">Order Date</option>
                          <option value="amount">Order Amount</option>
                          <option value="status">Status</option>
                        </select>
                      </div>
                      <div className="col-md-2 d-flex align-items-end">
                        <button 
                          className="btn btn-outline-secondary w-100"
                          onClick={() => {
                            setSearchTerm('');
                            setStatusFilter('all');
                            setSortBy('date');
                          }}
                        >
                          <i className="fas fa-undo me-1"></i>Reset
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Orders List */}
              <div className="col-12">
                <div className="card shadow border-0">
                  <div className="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 className="mb-0 fw-bold">
                      <i className="fas fa-list me-2 text-primary"></i>
                      Your Orders ({filteredOrders.length})
                    </h5>
                    <button className="btn btn-outline-primary btn-sm">
                      <i className="fas fa-download me-1"></i>Export History
                    </button>
                  </div>
                  <div className="card-body p-0">
                    {filteredOrders.length === 0 ? (
                      <div className="text-center py-5">
                        <i className="fas fa-search fs-1 text-muted mb-3"></i>
                        <h5 className="text-muted">No orders found</h5>
                        <p className="text-muted">Try adjusting your search or filter criteria</p>
                      </div>
                    ) : (
                      <div className="accordion accordion-flush" id="ordersAccordion">
                        {filteredOrders.map((order, index) => (
                          <div key={order.id} className="accordion-item">
                            <h2 className="accordion-header">
                              <button 
                                className="accordion-button collapsed"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target={`#order-${order.id}`}
                                aria-expanded="false"
                              >
                                <div className="d-flex justify-content-between align-items-center w-100 me-3">
                                  <div className="d-flex align-items-center">
                                    <div className="order-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3">
                                      <i className="fas fa-receipt"></i>
                                    </div>
                                    <div>
                                      <h6 className="mb-1 fw-bold">Order #{order.id}</h6>
                                      <small className="text-muted">
                                        {new Date(order.date).toLocaleDateString('en-US', {
                                          year: 'numeric',
                                          month: 'long',
                                          day: 'numeric'
                                        })}
                                      </small>
                                    </div>
                                  </div>
                                  <div className="d-flex align-items-center">
                                    <div className="me-4">
                                      <div className="fw-bold text-success">${order.total?.toFixed(2) || '0.00'}</div>
                                      <small className="text-muted">{order.items?.length || 0} items</small>
                                    </div>
                                    <div className="me-3">
                                      {getStatusBadge(order.status || 'pending')}
                                    </div>
                                  </div>
                                </div>
                              </button>
                            </h2>
                            <div 
                              id={`order-${order.id}`} 
                              className="accordion-collapse collapse"
                              data-bs-parent="#ordersAccordion"
                            >
                              <div className="accordion-body">
                                <div className="row">
                                  <div className="col-md-8">
                                    <h6 className="fw-bold mb-3">Order Items</h6>
                                    <div className="table-responsive">
                                      <table className="table table-sm">
                                        <thead>
                                          <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Subtotal</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {order.items?.map(item => (
                                            <tr key={item.id}>
                                              <td>
                                                <div className="d-flex align-items-center">
                                                  <div className="product-icon bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                                    <i className="fas fa-seedling"></i>
                                                  </div>
                                                  <span className="fw-bold">{item.name}</span>
                                                </div>
                                              </td>
                                              <td>{item.quantity} kg</td>
                                              <td>${item.price}</td>
                                              <td className="fw-bold">${(item.price * item.quantity).toFixed(2)}</td>
                                            </tr>
                                          ))}
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                  <div className="col-md-4">
                                    <h6 className="fw-bold mb-3">Order Summary</h6>
                                    <div className="card bg-light">
                                      <div className="card-body">
                                        <div className="d-flex justify-content-between mb-2">
                                          <span>Order Total:</span>
                                          <span className="fw-bold text-success">${order.total?.toFixed(2) || '0.00'}</span>
                                        </div>
                                        <div className="d-flex justify-content-between mb-2">
                                          <span>Delivery Option:</span>
                                          <span className="text-capitalize">{order.deliveryOption || 'Standard'}</span>
                                        </div>
                                        {order.coupon && (
                                          <div className="d-flex justify-content-between mb-2">
                                            <span>Coupon Used:</span>
                                            <span className="badge bg-success">{order.coupon}</span>
                                          </div>
                                        )}
                                        <hr />
                                        <div className="d-grid gap-2">
                                          <button className="btn btn-outline-primary btn-sm">
                                            <i className="fas fa-eye me-1"></i>View Details
                                          </button>
                                          <button className="btn btn-outline-success btn-sm">
                                            <i className="fas fa-redo me-1"></i>Reorder
                                          </button>
                                          <button className="btn btn-outline-info btn-sm">
                                            <i className="fas fa-download me-1"></i>Download Invoice
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Styles */}
      <style >{`
        .order-icon {
          width: 40px;
          height: 40px;
          font-size: 1.1rem;
        }
        
        .product-icon {
          width: 30px;
          height: 30px;
          font-size: 0.9rem;
        }
        
        .bg-gradient-primary {
          background: linear-gradient(135deg, #007bff, #6610f2);
        }
        
        .bg-gradient-success {
          background: linear-gradient(135deg, #28a745, #20c997);
        }
        
        .bg-gradient-warning {
          background: linear-gradient(135deg, #ffc107, #fd7e14);
        }
        
        .bg-gradient-info {
          background: linear-gradient(135deg, #17a2b8, #6f42c1);
        }
        
        .accordion-button:not(.collapsed) {
          background-color: rgba(0,123,255,0.1);
          color: #0056b3;
        }
        
        .accordion-button:focus {
          box-shadow: none;
          border-color: #0056b3;
        }
      `}</style>
    </div>
  );
};

export default PastOrdersPage;