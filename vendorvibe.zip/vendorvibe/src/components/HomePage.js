// components/HomePage.js
import React from 'react';

const HomePage = ({ onViewChange }) => {
  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center bg-gradient-primary">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-8 col-md-10">
            <div className="card shadow-lg border-0 rounded-4">
              <div className="card-body p-5 text-center">
                {/* Header Section */}
                <div className="mb-5">
                  <div className="display-1 text-primary mb-3">
                    <i className="fas fa-handshake"></i>
                  </div>
                  <h1 className="display-3 fw-bold text-primary mb-3">VendorVibe</h1>
                  <p className="lead text-muted fst-italic mb-2">Your Virtual Marketplace Bridge</p>
                  <p className="text-secondary fs-5">Connecting vendors and suppliers seamlessly across the digital marketplace</p>
                </div>
                
                {/* Feature Cards */}
                <div className="row g-4 mb-5">
                  <div className="col-lg-6">
                    <div className="card h-100 border-primary shadow-sm user-card">
                      <div className="card-body d-flex flex-column p-4">
                        <div className="text-primary mb-3">
                          <i className="fas fa-store fs-1"></i>
                        </div>
                        <h4 className="card-title fw-bold text-primary">I'm a Vendor</h4>
                        <p className="card-text flex-grow-1 text-muted fs-6">
                          Find verified suppliers, manage your inventory, and streamline your procurement process with ease
                        </p>
                        <div className="mt-auto">
                          <button 
                            className="btn btn-primary btn-lg w-100 shadow"
                            onClick={() => onViewChange('vendorLogin')}
                          >
                            <i className="fas fa-arrow-right me-2"></i>Get Started as Vendor
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="col-lg-6">
                    <div className="card h-100 border-success shadow-sm user-card">
                      <div className="card-body d-flex flex-column p-4">
                        <div className="text-success mb-3">
                          <i className="fas fa-truck fs-1"></i>
                        </div>
                        <h4 className="card-title fw-bold text-success">I'm a Supplier</h4>
                        <p className="card-text flex-grow-1 text-muted fs-6">
                          Connect with vendors, showcase your products, and expand your business reach across the platform
                        </p>
                        <div className="mt-auto">
                          <button 
                            className="btn btn-success btn-lg w-100 shadow"
                            onClick={() => onViewChange('supplierLogin')}
                          >
                            <i className="fas fa-arrow-right me-2"></i>Get Started as Supplier
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Features Section */}
                <div className="row text-center mb-4">
                  <div className="col-md-4 mb-3">
                    <div className="feature-item">
                      <i className="fas fa-shield-alt fs-2 text-success mb-2"></i>
                      <h6 className="fw-bold">Verified Partners</h6>
                      <small className="text-muted">All suppliers are KYC verified</small>
                    </div>
                  </div>
                  <div className="col-md-4 mb-3">
                    <div className="feature-item">
                      <i className="fas fa-bolt fs-2 text-warning mb-2"></i>
                      <h6 className="fw-bold">Fast Transactions</h6>
                      <small className="text-muted">Quick and secure payments</small>
                    </div>
                  </div>
                  <div className="col-md-4 mb-3">
                    <div className="feature-item">
                      <i className="fas fa-headset fs-2 text-info mb-2"></i>
                      <h6 className="fw-bold">24/7 Support</h6>
                      <small className="text-muted">Round the clock assistance</small>
                    </div>
                  </div>
                </div>

                {/* Call to Action */}
                <div className="text-center">
                  <p className="text-muted mb-3">Join thousands of businesses already using VendorVibe</p>
                  <small className="text-muted">
                    <i className="fas fa-lock me-1"></i>
                    Secure • Reliable • Efficient
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Custom Styles */}
      <style >{`
        .bg-gradient-primary {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .user-card {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .user-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 12px 25px rgba(0,0,0,0.15) !important;
        }
        
        .feature-item {
          padding: 1rem;
          border-radius: 10px;
          transition: background-color 0.3s ease;
        }
        
        .feature-item:hover {
          background-color: rgba(255,255,255,0.1);
        }
        
        .btn {
          transition: all 0.3s ease;
        }
        
        .btn:hover {
          transform: translateY(-2px);
        }
      `}</style>
    </div>
  );
};

export default HomePage;