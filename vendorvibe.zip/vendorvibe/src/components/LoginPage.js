// components/LoginPage.js - Updated with proper async handling
import React, { useState } from 'react';

const LoginPage = ({ type, onLogin, onViewChange, isLoading }) => {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    // Clear error when user starts typing
    if (error) setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Prevent multiple submissions
    if (loading || isLoading) {
      console.log('Login already in progress, preventing duplicate submission');
      return;
    }

    setLoading(true);
    setError('');
    
    // Basic form validation
    if (!formData.username.trim() || !formData.password) {
      setError('Please fill in all fields');
      setLoading(false);
      return;
    }
    
    try {
      console.log('LoginPage - Submitting login for:', formData.username);
      
      const result = await onLogin(formData.username, formData.password, type);
      
      if (!result.success) {
        setError(result.message || 'Invalid credentials. Please check your username and password.');
      }
      // If successful, App.js will handle the navigation
    } catch (error) {
      console.error('LoginPage - Login error:', error);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const buttonColor = type === 'vendor' ? 'primary' : 'success';
  const iconClass = type === 'vendor' ? 'fas fa-store' : 'fas fa-truck';
  const isFormDisabled = loading || isLoading;

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-5 col-md-7 col-sm-9">
            <div className="card shadow-lg border-0 rounded-4">
              <div className="card-body p-5">
                {/* Header */}
                <div className="text-center mb-4">
                  <div className={`text-${buttonColor} mb-3`}>
                    <i className={`${iconClass} fs-1`}></i>
                  </div>
                  <h2 className="fw-bold text-primary mb-2">VendorVibe</h2>
                  <h4 className="text-capitalize mb-2">{type} Login</h4>
                  <p className="text-muted">Welcome back! Please sign in to continue.</p>
                </div>

                {/* Error Alert */}
                {error && (
                  <div className="alert alert-danger alert-dismissible fade show" role="alert">
                    <i className="fas fa-exclamation-triangle me-2"></i>
                    {error}
                    <button 
                      type="button" 
                      className="btn-close" 
                      onClick={() => setError('')}
                      aria-label="Close"
                    ></button>
                  </div>
                )}

                {/* Login Form */}
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label fw-semibold">
                      <i className="fas fa-user me-2"></i>Username
                    </label>
                    <input 
                      type="text" 
                      name="username"
                      className={`form-control form-control-lg ${error ? 'is-invalid' : ''}`}
                      value={formData.username}
                      onChange={handleChange}
                      placeholder="Enter your username"
                      disabled={isFormDisabled}
                      required
                      autoComplete="username"
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label className="form-label fw-semibold">
                      <i className="fas fa-lock me-2"></i>Password
                    </label>
                    <input 
                      type="password" 
                      name="password"
                      className={`form-control form-control-lg ${error ? 'is-invalid' : ''}`}
                      value={formData.password}
                      onChange={handleChange}
                      placeholder="Enter your password"
                      disabled={isFormDisabled}
                      required
                      autoComplete="current-password"
                    />
                  </div>

                  {/* Login Button */}
                  <button 
                    type="submit" 
                    className={`btn btn-${buttonColor} btn-lg w-100 mb-3 shadow`}
                    disabled={isFormDisabled}
                  >
                    {isFormDisabled ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        Signing in...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-sign-in-alt me-2"></i>Sign In
                      </>
                    )}
                  </button>
                </form>

                {/* Additional Links */}
                <div className="text-center mb-4">
                  <button 
                    className="btn btn-link text-decoration-none p-0"
                    onClick={() => alert('Password reset functionality coming soon!')}
                    disabled={isFormDisabled}
                  >
                    <i className="fas fa-key me-1"></i>Forgot Password?
                  </button>
                </div>

                <hr className="my-4" />

                {/* Register Link */}
                <div className="text-center mb-3">
                  <p className="text-muted mb-2">Don't have an account?</p>
                  <button 
                    className={`btn btn-outline-${buttonColor} w-100 mb-3`}
                    onClick={() => onViewChange(type === 'vendor' ? 'vendorRegister' : 'supplierRegister')}
                    disabled={isFormDisabled}
                  >
                    <i className="fas fa-user-plus me-2"></i>Create New Account
                  </button>
                </div>

                {/* Back to Home */}
                <div className="text-center">
                  <button 
                    className="btn btn-outline-secondary"
                    onClick={() => onViewChange('home')}
                    disabled={isFormDisabled}
                  >
                    <i className="fas fa-arrow-left me-2"></i>Back to Home
                  </button>
                </div>

                {/* Demo Credentials Info */}
                <div className="mt-4 p-3 bg-light rounded">
                  <small className="text-muted">
                    <strong>Demo Credentials:</strong><br />
                    Username: {type}1<br />
                    Password: pass123
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;