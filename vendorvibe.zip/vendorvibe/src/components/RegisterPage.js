import React, { useState } from 'react';

const RegisterPage = ({ type, onRegister, onViewChange }) => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    name: '',
    phone: '',
    gstin: '', // Added GSTIN field for suppliers
    userType: type,
    aadhaarNumber: '' // Added for vendors to store Aadhaar number
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    // Clear errors when user starts typing
    if (error) setError('');
  };

  const validateForm = () => {
    // Check required fields
    const requiredFields = ['username', 'password', 'name', 'phone'];
    if (type === 'supplier') {
      requiredFields.push('gstin');
    }
    if (type === 'vendor') {
      requiredFields.push('aadhaarNumber');
    }

    for (let field of requiredFields) {
      if (!formData[field]) {
        setError(`Please fill in all required fields.`);
        return false;
      }
    }

    // Check username length
    if (formData.username.length < 3) {
      setError('Username must be at least 3 characters long');
      return false;
    }

    // Check password match
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return false;
    }

    // Check password strength
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      return false;
    }

    // Check phone number format
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(formData.phone)) {
      setError('Please enter a valid 10-digit Indian phone number starting with 6-9');
      return false;
    }

    // Check name length
    if (formData.name.length < 2) {
      setError('Name must be at least 2 characters long');
      return false;
    }

    // Validate GSTIN for suppliers
    if (type === 'supplier' && formData.gstin) {
      const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
      if (!gstinRegex.test(formData.gstin)) {
        setError('Please enter a valid GSTIN (15 characters)');
        return false;
      }
    }

    // Validate Aadhaar Number for vendors
    if (type === 'vendor' && formData.aadhaarNumber) {
      const aadhaarRegex = /^\d{12}$/;
      if (!aadhaarRegex.test(formData.aadhaarNumber)) {
        setError('Aadhaar Number must be a 12-digit number');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      // Clean the data before sending
      const dataToRegister = {
        username: formData.username.trim(),
        password: formData.password,
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        userType: type
      };

      // Add type-specific fields only if they exist and are not empty
      if (type === 'supplier' && formData.gstin) {
        dataToRegister.gstin = formData.gstin.trim().toUpperCase();
      }
      
      if (type === 'vendor' && formData.aadhaarNumber) {
        dataToRegister.aadhaarNumber = formData.aadhaarNumber.trim();
      }

      console.log('Sending registration data:', dataToRegister);

      const result = await onRegister(dataToRegister);

      if (result && result.success) {
        setSuccess(result.message || 'Registration successful!');
        setTimeout(() => {
          onViewChange(type === 'vendor' ? 'vendorLogin' : 'supplierLogin');
        }, 2000);
      } else {
        setError(result?.message || result?.error || 'Registration failed. Please try again.');
      }
    } catch (error) {
      console.error('Registration error:', error);
      
      // Handle different types of errors
      if (error.response) {
        // Server responded with error status
        const status = error.response.status;
        const message = error.response.data?.message || error.response.data?.error;
        
        if (status === 400) {
          setError(message || 'Invalid registration data. Please check your inputs.');
        } else if (status === 409) {
          setError(message || 'Username already exists. Please choose a different username.');
        } else if (status === 500) {
          setError('Server error. Please try again later or contact support.');
        } else {
          setError(message || `Registration failed (Error ${status}). Please try again.`);
        }
      } else if (error.request) {
        // Network error
        setError('Network error. Please check your internet connection and try again.');
      } else {
        // Other error
        setError('An unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const buttonColor = type === 'vendor' ? 'primary' : 'success';
  const iconClass = type === 'vendor' ? 'fas fa-store' : 'fas fa-truck';

  return (
    <div className="min-vh-100 d-flex align-items-center justify-content-center bg-light py-5">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-8 col-md-10">
            <div className="card shadow-lg border-0 rounded-4">
              <div className="card-body p-5">
                {/* Header */}
                <div className="text-center mb-4">
                  <div className={`text-${buttonColor} mb-3`}>
                    <i className={`${iconClass} fs-1`}></i>
                  </div>
                  <h2 className="fw-bold text-primary mb-2">VendorVibe</h2>
                  <h4 className="text-capitalize">{type} Registration</h4>
                  <p className="text-muted">Join our platform and start growing your business</p>
                </div>

                {/* Alerts */}
                {error && (
                  <div className="alert alert-danger alert-dismissible fade show">
                    <i className="fas fa-exclamation-triangle me-2"></i>
                    {error}
                    <button
                      type="button"
                      className="btn-close"
                      onClick={() => setError('')}
                      aria-label="Close"
                    ></button>
                  </div>
                )}

                {success && (
                  <div className="alert alert-success alert-dismissible fade show">
                    <i className="fas fa-check-circle me-2"></i>
                    {success}
                    <button
                      type="button"
                      className="btn-close"
                      onClick={() => setSuccess('')}
                      aria-label="Close"
                    ></button>
                  </div>
                )}

                {/* Registration Form */}
                <form onSubmit={handleSubmit}>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">
                        <i className="fas fa-user me-2"></i>Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        className="form-control"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">
                        <i className="fas fa-phone me-2"></i>Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        className="form-control"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="10-digit mobile number"
                        maxLength="10"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-semibold">
                      <i className="fas fa-at me-2"></i>Username *
                    </label>
                    <input
                      type="text"
                      name="username"
                      className="form-control"
                      value={formData.username}
                      onChange={handleChange}
                      placeholder="Choose a unique username"
                      required
                    />
                  </div>

                  {/* GSTIN field for suppliers only */}
                  {type === 'supplier' && (
                    <div className="mb-3">
                      <label className="form-label fw-semibold">
                        <i className="fas fa-file-invoice me-2"></i>GSTIN *
                      </label>
                      <input
                        type="text"
                        name="gstin"
                        className="form-control"
                        value={formData.gstin}
                        onChange={handleChange}
                        placeholder="Enter your GSTIN"
                        maxLength="15"
                        style={{ textTransform: 'uppercase' }}
                        required
                      />
                      <div className="form-text">
                        <i className="fas fa-info-circle me-1"></i>
                        Enter 15-character GSTIN (e.g., 22AAAAA0000A1Z5)
                      </div>
                    </div>
                  )}

                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">
                        <i className="fas fa-lock me-2"></i>Password *
                      </label>
                      <input
                        type="password"
                        name="password"
                        className="form-control"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Minimum 6 characters"
                        required
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">
                        <i className="fas fa-lock me-2"></i>Confirm Password *
                      </label>
                      <input
                        type="password"
                        name="confirmPassword"
                        className="form-control"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        placeholder="Re-enter password"
                        required
                      />
                    </div>
                  </div>

                  {/* Aadhaar Number input for vendors only */}
                  {type === 'vendor' && (
                    <div className="mb-4">
                      <label className="form-label fw-semibold">
                        <i className="fas fa-id-card me-2"></i>Aadhaar Number *
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        name="aadhaarNumber"
                        value={formData.aadhaarNumber}
                        onChange={handleChange}
                        placeholder="Enter your 12-digit Aadhaar number"
                        maxLength="12"
                        pattern="\d{12}"
                        required
                      />
                      <div className="form-text">
                        <i className="fas fa-info-circle me-1"></i>
                        Enter your 12-digit Aadhaar card number
                      </div>
                    </div>
                  )}

                  {/* Terms and Conditions */}
                  <div className="mb-4">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" id="termsCheck" required />
                      <label className="form-check-label" htmlFor="termsCheck">
                        I agree to the <a href="#" className="text-decoration-none">Terms of Service</a> and <a href="#" className="text-decoration-none">Privacy Policy</a>
                      </label>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className={`btn btn-${buttonColor} btn-lg w-100 mb-3 shadow`}
                    disabled={loading || success !== ''}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        Creating Account...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-user-plus me-2"></i>Create Account
                      </>
                    )}
                  </button>
                </form>

                <hr className="my-4" />

                {/* Navigation Links */}
                <div className="text-center">
                  <p className="text-muted mb-3">Already have an account?</p>
                  <button
                    className={`btn btn-outline-${buttonColor} me-3`}
                    onClick={() => onViewChange(type === 'vendor' ? 'vendorLogin' : 'supplierLogin')}
                  >
                    <i className="fas fa-sign-in-alt me-2"></i>Sign In
                  </button>
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => onViewChange('home')}
                  >
                    <i className="fas fa-arrow-left me-2"></i>Back to Home
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;