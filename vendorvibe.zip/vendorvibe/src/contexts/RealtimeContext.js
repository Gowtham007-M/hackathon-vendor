// src/contexts/RealtimeContext.js
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import io from 'socket.io-client';

// Create contexts
const RealtimeContext = createContext();
const RealtimeProductsContext = createContext();
const RealtimeOrdersContext = createContext();
const RealtimeSuppliersContext = createContext(); // New context for suppliers


// Main Realtime Provider
export const RealtimeProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [suppliers, setSuppliers] = useState([]); // New state for suppliers
  const [onlineUsers, setOnlineUsers] = useState(new Set());

  // Connect to WebSocket
  const connectSocket = useCallback((token) => {
    if (socket) {
      socket.disconnect();
    }

    const newSocket = io(process.env.REACT_APP_SERVER_URL || 'http://localhost:5000', {
      auth: {
        token: token
      },
      transports: ['websocket', 'polling'],
      withCredentials: true
    });

    newSocket.on('connect', () => {
      console.log('Connected to WebSocket server');
      setIsConnected(true);
      addNotification('Connected to real-time updates', 'success', 3000);
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from WebSocket server');
      setIsConnected(false);
      addNotification('Disconnected from real-time updates', 'warning', 3000);
    });

    newSocket.on('connect_error', (error) => {
      console.error('WebSocket connection error:', error);
      setIsConnected(false);
      addNotification('Failed to connect to real-time updates', 'error', 5000);
    });

    // Authentication events
    newSocket.on('authenticated', (data) => {
      console.log('Authenticated with server:', data);
      addNotification('Real-time connection authenticated', 'success', 2000);
    });

    newSocket.on('auth_error', (error) => {
      console.error('Authentication error:', error);
      addNotification('Authentication failed', 'error', 5000);
    });

    // Product-related events
    newSocket.on('product_added', (product) => {
      console.log('New product added:', product);
      setProducts(prev => {
        const exists = prev.find(p => p._id === product._id);
        if (!exists) {
          return [...prev, product];
        }
        return prev;
      });
      addNotification(
        `New product available: ${product.name}`,
        'info',
        4000
      );
    });

    newSocket.on('product_updated', (updatedProduct) => {
      console.log('Product updated:', updatedProduct);
      setProducts(prev =>
        prev.map(p => p._id === updatedProduct._id ? updatedProduct : p)
      );
      addNotification(
        `Product updated: ${updatedProduct.name}`,
        'info',
        4000
      );
    });

    newSocket.on('product_deleted', (productId) => {
      console.log('Product deleted:', productId);
      setProducts(prev => prev.filter(p => p._id !== productId));
      addNotification('A product has been removed', 'warning', 3000);
    });

    newSocket.on('product_stock_updated', ({ productId, newStock, productName }) => {
      console.log('Product stock updated:', { productId, newStock });
      setProducts(prev =>
        prev.map(p => p._id === productId ? { ...p, available: newStock } : p)
      );
      if (newStock < 10) {
        addNotification(
          `Low stock alert: ${productName} (${newStock} remaining)`,
          'warning',
          6000
        );
      }
    });

    // Order-related events
    newSocket.on('order_created', (order) => {
      console.log('New order created:', order);
      setOrders(prev => {
        const exists = prev.find(o => o._id === order._id);
        if (!exists) {
          return [order, ...prev];
        }
        return prev;
      });
      addNotification(
        `New order received: #${order.orderId}`,
        'success',
        5000
      );
    });

    newSocket.on('order_updated', (updatedOrder) => {
      console.log('Order updated:', updatedOrder);
      setOrders(prev =>
        prev.map(o => o._id === updatedOrder._id ? updatedOrder : o)
      );
      addNotification(
        `Order #${updatedOrder.orderId} status: ${updatedOrder.status}`,
        'info',
        4000
      );
    });

    newSocket.on('order_status_changed', ({ orderId, newStatus, message }) => {
      console.log('Order status changed:', { orderId, newStatus });
      setOrders(prev =>
        prev.map(o => o.orderId === orderId ? {...o, status: newStatus} : o)
      );
      if (message) {
        addNotification(message, 'info', 4000);
      }
    });

    newSocket.on('order_cancelled', (orderId) => {
      console.log('Order cancelled:', orderId);
      setOrders(prev =>
        prev.map(o => o.orderId === orderId ? {...o, status: 'cancelled'} : o)
      );
      addNotification('An order has been cancelled', 'warning', 4000);
    });

    // Supplier-related events (New)
    newSocket.on('supplier_added', (supplier) => {
      console.log('New supplier added:', supplier);
      setSuppliers(prev => {
        const exists = prev.find(s => s._id === supplier._id);
        if (!exists) {
          return [...prev, supplier];
        }
        return prev;
      });
      addNotification(`New supplier registered: ${supplier.name}`, 'info', 4000);
    });

    newSocket.on('supplier_updated', (updatedSupplier) => {
      console.log('Supplier updated:', updatedSupplier);
      setSuppliers(prev =>
        prev.map(s => s._id === updatedSupplier._id ? updatedSupplier : s)
      );
      addNotification(`Supplier updated: ${updatedSupplier.name}`, 'info', 4000);
    });

    newSocket.on('supplier_deleted', (supplierId) => {
      console.log('Supplier deleted:', supplierId);
      setSuppliers(prev => prev.filter(s => s._id !== supplierId));
      addNotification('A supplier has been removed', 'warning', 3000);
    });

    // User presence events
    newSocket.on('user_online', ({ userId, userType, name }) => {
      console.log('User came online:', { userId, userType, name });
      setOnlineUsers(prev => new Set([...prev, `${userType}_${userId}`]));
      addNotification(`${name} is now online`, 'info', 2000);
    });

    newSocket.on('user_offline', ({ userId, userType }) => {
      console.log('User went offline:', { userId, userType });
      setOnlineUsers(prev => {
        const newSet = new Set(prev);
        newSet.delete(`${userType}_${userId}`);
        return newSet;
      });
    });

    // General notifications
    newSocket.on('notification', (notification) => {
      console.log('General notification:', notification);
      addNotification(
        notification.message,
        notification.type || 'info',
        notification.duration || 4000
      );
    });

    // Bulk update events
    newSocket.on('products_bulk_update', (updatedProducts) => {
      console.log('Bulk products update:', updatedProducts);
      setProducts(updatedProducts);
      addNotification('Product catalog updated', 'info', 3000);
    });

    newSocket.on('orders_bulk_update', (updatedOrders) => {
      console.log('Bulk orders update:', updatedOrders);
      setOrders(updatedOrders);
      addNotification('Orders updated', 'info', 3000);
    });

    newSocket.on('suppliers_bulk_update', (updatedSuppliers) => { // New bulk update for suppliers
      console.log('Bulk suppliers update:', updatedSuppliers);
      setSuppliers(updatedSuppliers);
      addNotification('Supplier catalog updated', 'info', 3000);
    });

    // Typing indicators
    newSocket.on('user_typing', ({ userId, isTyping }) => {
      console.log(`User ${userId} is ${isTyping ? 'typing' : 'stopped typing'}`);
      // Handle typing indicators if needed
    });

    // System notifications
    newSocket.on('system_message', ({ message, type, priority }) => {
      addNotification(
        message,
        type || 'info',
        priority === 'high' ? 8000 : 4000
      );
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  // Disconnect socket
  const disconnectSocket = useCallback(() => {
    if (socket) {
      socket.disconnect();
      setSocket(null);
      setIsConnected(false);
    }
  }, [socket]);

  // Add notification
  const addNotification = useCallback((message, type = 'info', duration = 4000) => {
    const id = Date.now() + Math.random();
    const notification = {
      id,
      message,
      type,
      timestamp: new Date(),
      duration
    };

    setNotifications(prev => [notification, ...prev.slice(0, 4)]); // Keep only 5 notifications

    // Auto remove notification
    if (duration > 0) {
      setTimeout(() => {
        removeNotification(id);
      }, duration);
    }

    return id;
  }, []);

  // Remove notification
  const removeNotification = useCallback((id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  // Clear all notifications
  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Emit events
  const emitEvent = useCallback((event, data) => {
    if (socket && isConnected) {
      console.log('Emitting event:', event, data);
      socket.emit(event, data);
    } else {
      console.warn('Cannot emit event - socket not connected:', event);
    }
  }, [socket, isConnected]);

  // Subscribe to events
  const on = useCallback((event, callback) => {
    if (socket) {
      socket.on(event, callback);
    }
  }, [socket]);

  // Unsubscribe from events
  const off = useCallback((event, callback) => {
    if (socket) {
      socket.off(event, callback);
    }
  }, [socket]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, [socket]);

  const contextValue = {
    socket,
    isConnected,
    notifications,
    onlineUsers,
    connectSocket,
    disconnectSocket,
    addNotification,
    removeNotification,
    clearNotifications,
    emitEvent,
    on,
    off
  };

  const productsContextValue = {
    products,
    setProducts
  };

  const ordersContextValue = {
    orders,
    setOrders
  };

  const suppliersContextValue = { // New context value for suppliers
    suppliers,
    setSuppliers
  };

  return (
    <RealtimeContext.Provider value={contextValue}>
      <RealtimeProductsContext.Provider value={productsContextValue}>
        <RealtimeOrdersContext.Provider value={ordersContextValue}>
          <RealtimeSuppliersContext.Provider value={suppliersContextValue}> {/* New Provider for suppliers */}
            {children}
          </RealtimeSuppliersContext.Provider>
        </RealtimeOrdersContext.Provider>
      </RealtimeProductsContext.Provider>
    </RealtimeContext.Provider>
  );
};

// Custom hooks
export const useRealtime = () => {
  const context = useContext(RealtimeContext);
  if (!context) {
    throw new Error('useRealtime must be used within a RealtimeProvider');
  }
  return context;
};

export const useRealtimeProducts = () => {
  const context = useContext(RealtimeProductsContext);
  if (!context) {
    throw new Error('useRealtimeProducts must be used within a RealtimeProvider');
  }
  return context;
};

export const useRealtimeOrders = () => {
  const context = useContext(RealtimeOrdersContext);
  if (!context) {
    throw new Error('useRealtimeOrders must be used within a RealtimeProvider');
  }
  return context;
};

export const useRealtimeSuppliers = () => { // New custom hook for suppliers
  const context = useContext(RealtimeSuppliersContext);
  if (!context) {
    throw new Error('useRealtimeSuppliers must be used within a RealtimeProvider');
  }
  return context;
};


// Enhanced Notification Component
export const NotificationContainer = () => {
  const { notifications, removeNotification } = useRealtime();

  if (notifications.length === 0) return null;

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'success': return 'fas fa-check-circle';
      case 'error': return 'fas fa-exclamation-circle';
      case 'warning': return 'fas fa-exclamation-triangle';
      case 'info': return 'fas fa-info-circle';
      default: return 'fas fa-bell';
    }
  };

  const getNotificationClass = (type) => {
    switch (type) {
      case 'error': return 'alert-danger';
      case 'success': return 'alert-success';
      case 'warning': return 'alert-warning';
      case 'info': return 'alert-info';
      default: return 'alert-primary';
    }
  };

  return (
    <>
      <div className="notification-container position-fixed" style={{
        top: '100px',
        right: '20px',
        zIndex: 9999,
        maxWidth: '400px'
      }}>
        {notifications.map(notification => (
          <div
            key={notification.id}
            className={`alert ${getNotificationClass(notification.type)} alert-dismissible fade show notification-item`}
            style={{
              marginBottom: '10px',
              animation: 'slideInRight 0.3s ease-out',
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              border: 'none'
            }}
          >
            <div className="d-flex align-items-center">
              <i className={`${getNotificationIcon(notification.type)} me-2`}></i>
              <div className="flex-grow-1">
                <div className="fw-medium">{notification.message}</div>
                <small className="text-muted">
                  {notification.timestamp.toLocaleTimeString()}
                </small>
              </div>
            </div>
            <button
              type="button"
              className="btn-close"
              onClick={() => removeNotification(notification.id)}
            ></button>
          </div>
        ))}
      </div>

      <style jsx>{`
        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(100%);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        .notification-container {
          pointer-events: none;
        }

        .notification-item {
          pointer-events: auto;
        }
      `}</style>
    </>
  );
};

// Connection Status Component
export const ConnectionStatus = () => {
  const { isConnected } = useRealtime();

  return (
    <div
      className={`badge ${isConnected ? 'bg-success' : 'bg-danger'} position-fixed`}
      style={{top: '80px', right: '20px', zIndex: 1050}}
    >
      <i className={`fas fa-${isConnected ? 'wifi' : 'exclamation-triangle'} me-1`}></i>
      {isConnected ? 'Live' : 'Offline'}
    </div>
  );
};

// Real-time Activity Feed Hook
export const useRealtimeActivity = () => {
  const { socket } = useRealtime(); // Removed addNotification as it's not directly used here
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    if (!socket) return;

    const handleActivity = (activity) => {
      setActivities(prev => [activity, ...prev.slice(0, 49)]); // Keep last 50 activities
    };

    socket.on('activity_feed', handleActivity);

    return () => {
      socket.off('activity_feed', handleActivity);
    };
  }, [socket]);

  return { activities, setActivities };
};